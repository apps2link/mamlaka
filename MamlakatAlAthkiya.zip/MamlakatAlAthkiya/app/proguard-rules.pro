# Kotlin / Compose / DataStore work with the default optimized rules.
-keepattributes *Annotation*
