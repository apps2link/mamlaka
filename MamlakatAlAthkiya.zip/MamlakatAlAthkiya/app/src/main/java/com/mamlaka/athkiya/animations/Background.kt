package com.mamlaka.athkiya.animations

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.mamlaka.athkiya.presentation.theme.Palette

/** Slowly drifting clouds. One cheap infinite transition per layer; static when motion is reduced. */
@Composable
fun CloudsLayer(
    modifier: Modifier = Modifier,
    speedMillis: Int = 90_000,
    yFraction: Float = 0.12f,
    scale: Float = 1f,
    alpha: Float = 0.85f,
) {
    val reduce = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "clouds")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(speedMillis, easing = LinearEasing)),
        label = "cloudDrift",
    )
    Canvas(modifier) {
        val shift = if (reduce) 0f else drift
        val unit = size.minDimension * 0.10f * scale
        for (i in 0 until 3) {
            // wraps from right to left; 1.4 widths of travel so clouds fully leave and re-enter
            val x = ((i * 0.5f + shift) % 1f) * size.width * 1.4f - size.width * 0.2f
            val y = size.height * (yFraction + i * 0.07f)
            val c = Color.White.copy(alpha = alpha)
            drawCircle(c, unit * 1.0f, Offset(x, y))
            drawCircle(c, unit * 1.3f, Offset(x + unit * 1.1f, y - unit * 0.4f))
            drawCircle(c, unit * 1.0f, Offset(x + unit * 2.2f, y))
            drawCircle(c, unit * 0.8f, Offset(x + unit * 3.0f, y + unit * 0.15f))
        }
    }
}

private fun DrawScope.hills(color: Color, baseY: Float, amplitude: Float) {
    val p = Path()
    p.moveTo(0f, size.height)
    p.lineTo(0f, baseY)
    p.cubicTo(size.width * 0.25f, baseY - amplitude, size.width * 0.45f, baseY + amplitude * 0.6f, size.width * 0.7f, baseY - amplitude * 0.4f)
    p.cubicTo(size.width * 0.85f, baseY - amplitude * 0.8f, size.width * 0.95f, baseY, size.width, baseY - amplitude * 0.3f)
    p.lineTo(size.width, size.height)
    p.close()
    drawPath(p, color)
}

/**
 * Layered kingdom backdrop: sky, sun, two cloud layers and two hill layers.
 * [parallax] (0..1, read during drawing only) shifts the hills at different speeds as a map scrolls.
 */
@Composable
fun KingdomBackground(
    modifier: Modifier = Modifier,
    parallax: () -> Float = { 0f },
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Palette.SkyTop, Palette.SkyBottom)))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.8f, size.height * 0.12f)
            drawCircle(Palette.Sun.copy(alpha = 0.35f), size.minDimension * 0.26f, center)
            drawCircle(Palette.Sun, size.minDimension * 0.13f, center)
        }
        CloudsLayer(Modifier.fillMaxSize(), speedMillis = 120_000, yFraction = 0.08f, scale = 0.8f, alpha = 0.7f)
        Canvas(Modifier.fillMaxSize()) {
            hills(Palette.HillFar, size.height * 0.80f - parallax() * size.height * 0.03f, size.height * 0.05f)
        }
        CloudsLayer(Modifier.fillMaxSize(), speedMillis = 70_000, yFraction = 0.20f, scale = 1.1f, alpha = 0.9f)
        Canvas(Modifier.fillMaxSize()) {
            hills(Palette.HillNear, size.height * 0.90f - parallax() * size.height * 0.06f, size.height * 0.04f)
        }
        content()
    }
}
