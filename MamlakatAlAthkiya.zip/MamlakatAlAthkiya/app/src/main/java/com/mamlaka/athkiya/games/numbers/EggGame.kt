package com.mamlaka.athkiya.games.numbers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.characters.Thing
import com.mamlaka.athkiya.characters.ThingIcon
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.games.common.NumberOptions
import com.mamlaka.athkiya.games.common.StageCard
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.GameTheme

private val Hay = Color(0xFFFFB740)
private val Wood = Color(0xFFB9722C)

/** Shelves of nests with eggs and chicks; count the eggs (or the chicks). Layout is shuffled every round. */
@Composable
fun EggGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { EggEngine.build(level) }
    val prompts = rounds.map { stringResource(if (it.ask == Slot.EGG) R.string.q_eggs else R.string.q_chicks) }

    GameShell(vm, GameId.EGGS, level, theme, rounds, prompts, onFinished, onBack) { round, control ->
        StageCard(Modifier.weight(1f)) {
            Column(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.SpaceEvenly) {
                for (r in 0 until round.rows) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Hay, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            for (c in 0 until round.cols) {
                                Box(Modifier.size(60.dp), contentAlignment = Alignment.Center) {
                                    when (round.slots[r * round.cols + c]) {
                                        Slot.EGG -> ThingIcon(Thing.EGG, 56.dp)
                                        Slot.CHICK -> ThingIcon(Thing.CHICK, 58.dp)
                                        Slot.EMPTY -> Unit
                                    }
                                }
                            }
                        }
                        Box(Modifier.fillMaxWidth().height(10.dp).background(Wood, RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)))
                    }
                }
            }
        }
        NumberOptions(round.options, theme.accent, control) { it == round.answer }
    }
}
