package com.mamlaka.athkiya.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

object Palette {
    val SkyTop = Color(0xFF7FD0FF)
    val SkyBottom = Color(0xFFD9F3FF)
    val Purple = Color(0xFF7C4DFF)
    val Orange = Color(0xFFFF9F43)
    val Green = Color(0xFF2ECC71)
    val Pink = Color(0xFFFF6FA5)
    val Teal = Color(0xFF1ABC9C)
    val Blue = Color(0xFF4A90E2)
    val Coral = Color(0xFFFF6B6B)
    val Sun = Color(0xFFFFC857)
    val GoldDark = Color(0xFFE0A100)
    val HillFar = Color(0xFF9BE3B0)
    val HillNear = Color(0xFF58D68D)
    val Ink = Color(0xFF2D2A4A)
}

/** Blend two colors (0 = this, 1 = other). */
fun Color.mix(other: Color, fraction: Float): Color =
    androidx.compose.ui.graphics.lerp(this, other, fraction)

object MamlakaType {
    private val family = FontFamily.SansSerif
    val Display = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 44.sp, textAlign = TextAlign.Center)
    val Title = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
    val Body = TextStyle(fontFamily = family, fontWeight = FontWeight.Bold, fontSize = 22.sp)
    val Button = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, textAlign = TextAlign.Center)
    val Letter = TextStyle(fontFamily = family, fontWeight = FontWeight.ExtraBold, fontSize = 84.sp, textAlign = TextAlign.Center)
}

@Composable
fun MamlakaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Palette.Purple,
            secondary = Palette.Orange,
            tertiary = Palette.Pink,
            background = Palette.SkyBottom,
            surface = Color.White,
            onPrimary = Color.White,
            onSurface = Palette.Ink,
        ),
        content = content,
    )
}
