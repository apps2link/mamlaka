package com.mamlaka.athkiya.games.letters

import com.mamlaka.athkiya.domain.ArabicLetter
import com.mamlaka.athkiya.domain.ArabicLetters
import kotlin.random.Random

data class LetterRound(val target: ArabicLetter, val options: List<ArabicLetter>)

/** Pure game logic ("tap the right letter"), no Android or UI dependencies, so it is unit-testable. */
object LetterTapEngine {
    const val ROUNDS = 8

    /** Younger children meet fewer letters; the pool widens with age. */
    fun poolSizeForAge(age: Int): Int = when {
        age <= 4 -> 12
        age == 5 -> 20
        else -> ArabicLetters.all.size
    }

    /** Fewer choices for the youngest children. */
    fun optionCountForAge(age: Int): Int = when {
        age <= 3 -> 2
        age <= 5 -> 3
        else -> 4
    }

    fun buildRounds(age: Int, random: Random = Random.Default): List<LetterRound> {
        val pool = ArabicLetters.all.take(poolSizeForAge(age))
        val optionCount = optionCountForAge(age)
        return pool.shuffled(random).take(ROUNDS).map { target ->
            val distractors = pool.filter { it != target }.shuffled(random).take(optionCount - 1)
            LetterRound(target, (distractors + target).shuffled(random))
        }
    }

    fun starsFor(mistakes: Int): Int = when {
        mistakes <= 1 -> 3
        mistakes <= 3 -> 2
        else -> 1
    }

    fun coinsFor(mistakes: Int): Int = (ROUNDS - mistakes).coerceAtLeast(1)
}
