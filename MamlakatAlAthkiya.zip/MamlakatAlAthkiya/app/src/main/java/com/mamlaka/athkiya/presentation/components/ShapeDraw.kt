package com.mamlaka.athkiya.presentation.components

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.starPath
import com.mamlaka.athkiya.presentation.theme.mix

enum class ShapeKind(@StringRes val label: Int, val color: Color) {
    CIRCLE(R.string.shape_circle, Color(0xFFFF6FA5)),
    SQUARE(R.string.shape_square, Color(0xFF4A90E2)),
    TRIANGLE(R.string.shape_triangle, Color(0xFFFFB02E)),
    RECTANGLE(R.string.shape_rectangle, Color(0xFF2ECC71)),
    DIAMOND(R.string.shape_diamond, Color(0xFF9B6BFF)),
    STAR(R.string.shape_star, Color(0xFFFF7A59)),
    HEXAGON(R.string.shape_hexagon, Color(0xFF1ABC9C)),
    OVAL(R.string.shape_oval, Color(0xFFE056C9)),
}

private fun polygon(c: Offset, points: List<Offset>): Path = Path().apply {
    points.forEachIndexed { i, p -> if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) }
    close()
}

fun DrawScope.drawShape(kind: ShapeKind, c: Offset, s: Float) {
    val fill = Brush.verticalGradient(
        listOf(kind.color.mix(Color.White, 0.3f), kind.color),
        startY = c.y - s / 2f,
        endY = c.y + s / 2f,
    )
    val outline = Stroke(width = s * 0.04f, join = StrokeJoin.Round)
    val edge = Color.White.copy(alpha = 0.8f)
    fun path(p: Path) {
        drawPath(p, fill)
        drawPath(p, edge, style = outline)
    }
    when (kind) {
        ShapeKind.CIRCLE -> {
            drawCircle(fill, s * 0.45f, c)
            drawCircle(edge, s * 0.45f, c, style = outline)
        }
        ShapeKind.SQUARE -> {
            val tl = Offset(c.x - s * 0.4f, c.y - s * 0.4f)
            drawRoundRect(fill, tl, Size(s * 0.8f, s * 0.8f), CornerRadius(s * 0.08f))
            drawRoundRect(edge, tl, Size(s * 0.8f, s * 0.8f), CornerRadius(s * 0.08f), style = outline)
        }
        ShapeKind.RECTANGLE -> {
            val tl = Offset(c.x - s * 0.47f, c.y - s * 0.28f)
            drawRoundRect(fill, tl, Size(s * 0.94f, s * 0.56f), CornerRadius(s * 0.07f))
            drawRoundRect(edge, tl, Size(s * 0.94f, s * 0.56f), CornerRadius(s * 0.07f), style = outline)
        }
        ShapeKind.TRIANGLE -> path(polygon(c, listOf(Offset(c.x, c.y - s * 0.44f), Offset(c.x + s * 0.48f, c.y + s * 0.38f), Offset(c.x - s * 0.48f, c.y + s * 0.38f))))
        ShapeKind.DIAMOND -> path(polygon(c, listOf(Offset(c.x, c.y - s * 0.48f), Offset(c.x + s * 0.34f, c.y), Offset(c.x, c.y + s * 0.48f), Offset(c.x - s * 0.34f, c.y))))
        ShapeKind.STAR -> path(starPath(Offset(c.x, c.y + s * 0.03f), s * 0.5f, s * 0.23f))
        ShapeKind.HEXAGON -> path(
            polygon(
                c,
                (0 until 6).map {
                    val a = Math.toRadians(it * 60.0)
                    Offset(c.x + (Math.cos(a) * s * 0.46f).toFloat(), c.y + (Math.sin(a) * s * 0.46f).toFloat())
                },
            )
        )
        ShapeKind.OVAL -> {
            val tl = Offset(c.x - s * 0.47f, c.y - s * 0.3f)
            drawOval(fill, tl, Size(s * 0.94f, s * 0.6f))
            drawOval(edge, tl, Size(s * 0.94f, s * 0.6f), style = outline)
        }
    }
}

@Composable
fun ShapeIcon(kind: ShapeKind, size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        drawShape(kind, Offset(this.size.width / 2f, this.size.height / 2f), this.size.minDimension)
    }
}

enum class Symbol { GREATER, EQUALS, LESS }

/**
 * Comparison symbol drawn by hand so right-to-left layout can never mirror it.
 * GREATER opens to the left (left side is bigger); LESS opens to the right.
 */
@Composable
fun SymbolIcon(symbol: Symbol, size: Dp, color: Color) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = Stroke(width = w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (symbol) {
            Symbol.GREATER -> drawPath(Path().apply { moveTo(w * 0.28f, h * 0.2f); lineTo(w * 0.72f, h * 0.5f); lineTo(w * 0.28f, h * 0.8f) }, color, style = stroke)
            Symbol.LESS -> drawPath(Path().apply { moveTo(w * 0.72f, h * 0.2f); lineTo(w * 0.28f, h * 0.5f); lineTo(w * 0.72f, h * 0.8f) }, color, style = stroke)
            Symbol.EQUALS -> {
                drawLine(color, Offset(w * 0.2f, h * 0.38f), Offset(w * 0.8f, h * 0.38f), w * 0.13f, StrokeCap.Round)
                drawLine(color, Offset(w * 0.2f, h * 0.62f), Offset(w * 0.8f, h * 0.62f), w * 0.13f, StrokeCap.Round)
            }
        }
    }
}
