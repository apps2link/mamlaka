package com.mamlaka.athkiya.games

import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.length.LengthGameScreen
import com.mamlaka.athkiya.games.numbers.ClockGameScreen
import com.mamlaka.athkiya.games.numbers.ComparisonGameScreen
import com.mamlaka.athkiya.games.numbers.CountingGameScreen
import com.mamlaka.athkiya.games.numbers.EggGameScreen
import com.mamlaka.athkiya.games.shapes.ShapesGameScreen
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.GameTheme

/** Each game has its own colour identity inside the shared kingdom style. */
fun GameId.theme(): GameTheme = when (this) {
    GameId.COUNTING -> GameTheme(Color(0xFFA8E6FF), Color(0xFF8FD96B), Color(0xFF2E9E4F))
    GameId.COMPARISON -> GameTheme(Color(0xFFFFF3B0), Color(0xFFFFDA7A), Color(0xFFF29100))
    GameId.EGGS -> GameTheme(Color(0xFFC6F1A8), Color(0xFFFFD27A), Color(0xFFE67E00))
    GameId.CLOCK -> GameTheme(Color(0xFFFF9A8F), Color(0xFFE8574F), Color(0xFFC0392B))
    GameId.SHAPES -> GameTheme(Color(0xFF9DB2FF), Color(0xFF6A7DEB), Color(0xFF3F51B5))
    GameId.LENGTH -> GameTheme(Color(0xFFFFF4B8), Color(0xFFC9B8FF), Color(0xFF7E57C2))
}

@Composable
fun GameHost(vm: AppViewModel, game: GameId, level: GameLevel, onFinished: () -> Unit, onBack: () -> Unit) {
    val theme = game.theme()
    when (game) {
        GameId.COUNTING -> CountingGameScreen(vm, level, theme, onFinished, onBack)
        GameId.COMPARISON -> ComparisonGameScreen(vm, level, theme, onFinished, onBack)
        GameId.EGGS -> EggGameScreen(vm, level, theme, onFinished, onBack)
        GameId.CLOCK -> ClockGameScreen(vm, level, theme, onFinished, onBack)
        GameId.SHAPES -> ShapesGameScreen(vm, level, theme, onFinished, onBack)
        GameId.LENGTH -> LengthGameScreen(vm, level, theme, onFinished, onBack)
    }
}
