package com.mamlaka.athkiya.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mamlaka.athkiya.domain.GameState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.gameDataStore: DataStore<Preferences> by preferencesDataStore(name = "mamlaka_progress")

private object Keys {
    val STARS = intPreferencesKey("stars")
    val COINS = intPreferencesKey("coins")
    val SESSIONS = intPreferencesKey("sessions")
    val POINTS = intPreferencesKey("points")
    const val BEST_PREFIX = "best_"
    val AGE = intPreferencesKey("age")
    val SOUND = booleanPreferencesKey("sound_on")
    val VOICE = booleanPreferencesKey("voice_on")
    val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
    val INTRO_SEEN = booleanPreferencesKey("intro_seen")
}

/** All progress and settings live on the device only (DataStore). Nothing is sent anywhere. */
class GameRepository(private val store: DataStore<Preferences>) {

    val state: Flow<GameState> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            GameState(
                loaded = true,
                stars = p[Keys.STARS] ?: 0,
                coins = p[Keys.COINS] ?: 0,
                points = p[Keys.POINTS] ?: 0,
                sessionsCompleted = p[Keys.SESSIONS] ?: 0,
                age = p[Keys.AGE] ?: 4,
                soundOn = p[Keys.SOUND] ?: true,
                voiceOn = p[Keys.VOICE] ?: true,
                reduceMotion = p[Keys.REDUCE_MOTION] ?: false,
                introSeen = p[Keys.INTRO_SEEN] ?: false,
                bestStars = p.asMap().entries
                    .filter { it.key.name.startsWith(Keys.BEST_PREFIX) && it.value is Int }
                    .associate { it.key.name.removePrefix(Keys.BEST_PREFIX) to (it.value as Int) },
            )
        }

    /** Adds a finished game's rewards; [bestKey] ("<game>_<LEVEL>") also keeps the best star count. */
    suspend fun addReward(stars: Int, coins: Int, points: Int = 0, bestKey: String? = null) {
        store.edit {
            it[Keys.STARS] = (it[Keys.STARS] ?: 0) + stars
            it[Keys.COINS] = (it[Keys.COINS] ?: 0) + coins
            it[Keys.POINTS] = (it[Keys.POINTS] ?: 0) + points
            it[Keys.SESSIONS] = (it[Keys.SESSIONS] ?: 0) + 1
            if (bestKey != null) {
                val key = intPreferencesKey(Keys.BEST_PREFIX + bestKey)
                it[key] = maxOf(it[key] ?: 0, stars)
            }
        }
    }

    suspend fun setAge(age: Int) {
        store.edit { it[Keys.AGE] = age.coerceIn(3, 6) }
    }

    suspend fun setSound(on: Boolean) {
        store.edit { it[Keys.SOUND] = on }
    }

    suspend fun setVoice(on: Boolean) {
        store.edit { it[Keys.VOICE] = on }
    }

    suspend fun setReduceMotion(on: Boolean) {
        store.edit { it[Keys.REDUCE_MOTION] = on }
    }

    suspend fun setIntroSeen() {
        store.edit { it[Keys.INTRO_SEEN] = true }
    }

    /** Clears stars, coins, points, best levels and completed games. Settings (age, sound, motion) are kept. */
    suspend fun resetProgress() {
        store.edit {
            it.remove(Keys.STARS)
            it.remove(Keys.COINS)
            it.remove(Keys.SESSIONS)
            it.remove(Keys.POINTS)
            it.asMap().keys.filter { k -> k.name.startsWith(Keys.BEST_PREFIX) }.forEach { k -> it.remove(intPreferencesKey(k.name)) }
        }
    }
}
