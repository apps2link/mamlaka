package com.mamlaka.athkiya.domain

import androidx.annotation.StringRes
import com.mamlaka.athkiya.R

enum class GameLevel(@StringRes val title: Int) {
    EASY(R.string.level_easy),
    MEDIUM(R.string.level_medium),
    HARD(R.string.level_hard);

    companion object {
        fun fromName(name: String?): GameLevel = entries.firstOrNull { it.name == name } ?: EASY
    }
}
