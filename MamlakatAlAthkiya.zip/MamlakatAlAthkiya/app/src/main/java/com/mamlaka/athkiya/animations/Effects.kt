package com.mamlaka.athkiya.animations

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.audio.LocalSfx
import com.mamlaka.athkiya.audio.Sound
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlin.math.cos
import kotlin.math.sin

/** True when the parent turned on "reduce motion"; every effect below respects it. */
val LocalReduceMotion = compositionLocalOf { false }

/** Press-to-squash button feel plus a soft tap sound. */
fun Modifier.bouncyClickable(onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val sfx = LocalSfx.current
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = source, indication = null) {
            sfx?.play(Sound.TAP)
            onClick()
        }
}

/** Small horizontal wobble for a wrong answer. Fires each time [trigger] changes to a value above 0. */
fun Modifier.shake(trigger: Int): Modifier = composed {
    val reduce = LocalReduceMotion.current
    val offset = remember { Animatable(0f) }
    LaunchedEffect(trigger) {
        if (trigger > 0 && !reduce) {
            repeat(3) {
                offset.animateTo(14f, tween(45))
                offset.animateTo(-14f, tween(45))
            }
            offset.animateTo(0f, tween(45))
        }
    }
    this.graphicsLayer { translationX = offset.value }
}

/** Gentle up/down floating (idle) or a bigger bounce (jump). */
fun Modifier.bob(amplitude: Dp = 6.dp, periodMillis: Int = 1400, delayMillis: Int = 0): Modifier = composed {
    val reduce = LocalReduceMotion.current
    val density = LocalDensity.current
    val transition = rememberInfiniteTransition(label = "bob")
    val v by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(periodMillis, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(delayMillis),
        ),
        label = "bobValue",
    )
    val amplitudePx = with(density) { amplitude.toPx() }
    this.graphicsLayer { translationY = if (reduce) 0f else -v * amplitudePx }
}

/** Left-right tilt, used for a waving greeting. */
fun Modifier.tilt(degrees: Float = 8f, periodMillis: Int = 700): Modifier = composed {
    val reduce = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "tilt")
    val v by transition.animateFloat(
        initialValue = -degrees,
        targetValue = degrees,
        animationSpec = infiniteRepeatable(tween(periodMillis, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "tiltValue",
    )
    this.graphicsLayer { rotationZ = if (reduce) 0f else v }
}

fun starPath(center: Offset, outer: Float, inner: Float): Path = Path().apply {
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outer else inner
        val a = Math.toRadians(-90.0 + i * 36.0)
        val x = center.x + (r * cos(a)).toFloat()
        val y = center.y + (r * sin(a)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/** Burst of stars flying outward. Fires each time [trigger] changes to a value above 0. */
@Composable
fun StarBurst(trigger: Int, modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val progress = remember { Animatable(1f) }
    LaunchedEffect(trigger) {
        if (trigger > 0 && !reduce) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
        }
    }
    Canvas(modifier) {
        val p = progress.value
        if (p < 1f) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension * 0.5f
            for (i in 0 until 10) {
                val angle = Math.toRadians(i * 36.0)
                val r = maxRadius * p
                val pos = Offset(center.x + (cos(angle) * r).toFloat(), center.y + (sin(angle) * r).toFloat())
                val color = if (i % 2 == 0) Palette.Sun else Palette.Pink
                drawPath(starPath(pos, 22f * (1f - p) + 8f, 10f * (1f - p) + 4f), color = color, alpha = 1f - p)
            }
        }
    }
}
