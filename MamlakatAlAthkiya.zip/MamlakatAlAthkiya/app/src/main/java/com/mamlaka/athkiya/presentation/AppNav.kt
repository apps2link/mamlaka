package com.mamlaka.athkiya.presentation

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mamlaka.athkiya.animations.LocalReduceMotion
import com.mamlaka.athkiya.audio.LocalSfx
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.domain.World
import com.mamlaka.athkiya.games.GameHost
import com.mamlaka.athkiya.games.letters.LetterTapGameScreen
import com.mamlaka.athkiya.presentation.screens.HomeScreen
import com.mamlaka.athkiya.presentation.screens.IntroScreen
import com.mamlaka.athkiya.presentation.screens.LevelScreen
import com.mamlaka.athkiya.presentation.screens.MapScreen
import com.mamlaka.athkiya.presentation.screens.ParentGateScreen
import com.mamlaka.athkiya.presentation.screens.ParentScreen
import com.mamlaka.athkiya.presentation.screens.ResultScreen
import com.mamlaka.athkiya.presentation.screens.SplashScreen
import com.mamlaka.athkiya.presentation.screens.WorldScreen

object Routes {
    const val SPLASH = "splash"
    const val INTRO = "intro"
    const val HOME = "home"
    const val MAP = "map"
    const val WORLD = "world/{id}"
    fun world(id: String) = "world/$id"
    const val GAME_LETTER_TAP = "game/letters_tap"
    const val LEVELS = "levels/{key}"
    fun levels(key: String) = "levels/$key"
    const val PLAY = "play/{key}/{level}"
    fun play(key: String, level: String) = "play/$key/$level"
    const val RESULT = "result"
    const val GATE = "gate"
    const val PARENT = "parent"
}

@Composable
fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    val state by vm.state.collectAsStateWithLifecycle()
    val reduce = state.reduceMotion

    CompositionLocalProvider(LocalReduceMotion provides reduce, LocalSfx provides vm.sfx) {
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            // Soft zoom + fade between screens; a plain short fade when motion is reduced.
            enterTransition = {
                if (reduce) fadeIn(tween(150)) else fadeIn(tween(350)) + scaleIn(initialScale = 0.92f, animationSpec = tween(350))
            },
            exitTransition = {
                if (reduce) fadeOut(tween(150)) else fadeOut(tween(250)) + scaleOut(targetScale = 1.04f, animationSpec = tween(250))
            },
            popEnterTransition = {
                if (reduce) fadeIn(tween(150)) else fadeIn(tween(350)) + scaleIn(initialScale = 0.92f, animationSpec = tween(350))
            },
            popExitTransition = {
                if (reduce) fadeOut(tween(150)) else fadeOut(tween(250)) + scaleOut(targetScale = 1.04f, animationSpec = tween(250))
            },
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(state = state) { introSeen ->
                    nav.navigate(if (introSeen) Routes.HOME else Routes.INTRO) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            }
            composable(Routes.INTRO) {
                IntroScreen(
                    onSpeak = vm.speaker::speak,
                    onDone = {
                        vm.markIntroSeen()
                        nav.navigate(Routes.HOME) { popUpTo(Routes.INTRO) { inclusive = true } }
                    },
                )
            }
            composable(Routes.HOME) {
                HomeScreen(
                    state = state,
                    onPlay = { nav.navigate(Routes.MAP) },
                    onParents = { nav.navigate(Routes.GATE) },
                )
            }
            composable(Routes.MAP) {
                MapScreen(
                    state = state,
                    onSpeak = vm.speaker::speak,
                    onBack = { nav.popBackStack() },
                    onWorld = { world -> nav.navigate(Routes.world(world.id)) },
                )
            }
            composable(
                Routes.WORLD,
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                val world = World.fromId(entry.arguments?.getString("id")) ?: World.LETTERS
                WorldScreen(
                    world = world,
                    state = state,
                    onSpeak = vm.speaker::speak,
                    onBack = { nav.popBackStack() },
                    onPlayLetterTap = { nav.navigate(Routes.GAME_LETTER_TAP) },
                    onPlayGame = { game -> nav.navigate(Routes.levels(game.key)) },
                )
            }
            composable(
                Routes.LEVELS,
                arguments = listOf(navArgument("key") { type = NavType.StringType }),
            ) { entry ->
                val game = GameId.fromKey(entry.arguments?.getString("key")) ?: GameId.COUNTING
                LevelScreen(
                    game = game,
                    state = state,
                    onSpeak = vm.speaker::speak,
                    onBack = { nav.popBackStack() },
                    onPlay = { level -> nav.navigate(Routes.play(game.key, level.name)) },
                )
            }
            composable(
                Routes.PLAY,
                arguments = listOf(
                    navArgument("key") { type = NavType.StringType },
                    navArgument("level") { type = NavType.StringType },
                ),
            ) { entry ->
                val game = GameId.fromKey(entry.arguments?.getString("key")) ?: GameId.COUNTING
                val level = GameLevel.fromName(entry.arguments?.getString("level"))
                GameHost(
                    vm = vm,
                    game = game,
                    level = level,
                    onFinished = { nav.navigate(Routes.RESULT) { popUpTo(Routes.PLAY) { inclusive = true } } },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.GAME_LETTER_TAP) {
                LetterTapGameScreen(
                    vm = vm,
                    onFinished = {
                        nav.navigate(Routes.RESULT) { popUpTo(Routes.GAME_LETTER_TAP) { inclusive = true } }
                    },
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.RESULT) {
                ResultScreen(
                    result = vm.lastResult,
                    state = state,
                    onAgain = {
                        val last = vm.lastResult
                        val lastLevel = last?.level
                        val route = if (last != null && lastLevel != null) Routes.play(last.gameKey, lastLevel.name) else Routes.GAME_LETTER_TAP
                        nav.navigate(route) { popUpTo(Routes.RESULT) { inclusive = true } }
                    },
                    onMap = { nav.popBackStack(Routes.MAP, inclusive = false) },
                )
            }
            composable(Routes.GATE) {
                ParentGateScreen(
                    onPassed = { nav.navigate(Routes.PARENT) { popUpTo(Routes.GATE) { inclusive = true } } },
                    onCancel = { nav.popBackStack() },
                )
            }
            composable(Routes.PARENT) {
                ParentScreen(vm = vm, state = state, onBack = { nav.popBackStack() })
            }
        }
    }
}
