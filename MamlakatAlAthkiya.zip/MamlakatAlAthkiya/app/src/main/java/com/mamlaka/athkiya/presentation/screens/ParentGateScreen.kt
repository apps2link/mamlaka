package com.mamlaka.athkiya.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.shake
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette

private data class GateQuestion(val a: Int, val b: Int, val choices: List<Int>) {
    val answer: Int get() = a * b
}

private fun newQuestion(): GateQuestion {
    val a = (6..9).random()
    val b = (6..9).random()
    val answer = a * b
    val wrong = generateSequence { answer + (-9..9).random() }
        .filter { it != answer && it > 0 }
        .distinct()
        .take(3)
        .toList()
    return GateQuestion(a, b, (wrong + answer).shuffled())
}

/** Grown-ups-only gate: a multiplication question that young children can't answer by tapping randomly. */
@Composable
fun ParentGateScreen(onPassed: () -> Unit, onCancel: () -> Unit) {
    var question by remember { mutableStateOf(newQuestion()) }
    var wrongCount by remember { mutableIntStateOf(0) }

    ScreenScaffold {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            TopBar(onBack = onCancel)
            Text(stringResource(R.string.gate_title), style = MamlakaType.Display, color = Palette.Purple)
            Text(
                stringResource(R.string.gate_question, question.a.toArabicDigits(), question.b.toArabicDigits()),
                style = MamlakaType.Title,
                color = Palette.Ink,
            )
            Column(Modifier.fillMaxWidth().shake(wrongCount), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                question.choices.chunked(2).forEach { rowChoices ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowChoices.forEach { value ->
                            BigButton(value.toArabicDigits(), Palette.Blue, Modifier.weight(1f)) {
                                if (value == question.answer) {
                                    onPassed()
                                } else {
                                    wrongCount++
                                    question = newQuestion()
                                }
                            }
                        }
                    }
                }
            }
            Column(Modifier.height(8.dp)) {}
            BigButton(stringResource(R.string.cancel), Palette.Coral, Modifier.fillMaxWidth(), onClick = onCancel)
        }
    }
}
