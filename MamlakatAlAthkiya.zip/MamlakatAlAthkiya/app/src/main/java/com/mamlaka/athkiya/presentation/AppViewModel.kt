package com.mamlaka.athkiya.presentation

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mamlaka.athkiya.audio.Sfx
import com.mamlaka.athkiya.audio.Speaker
import com.mamlaka.athkiya.data.GameRepository
import com.mamlaka.athkiya.data.gameDataStore
import com.mamlaka.athkiya.domain.GameResult
import com.mamlaka.athkiya.domain.GameState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = GameRepository(app.gameDataStore)

    val speaker = Speaker(app)
    val sfx = Sfx(app)

    val state: StateFlow<GameState> = repo.state
        .stateIn(viewModelScope, SharingStarted.Eagerly, GameState())

    var lastResult by mutableStateOf<GameResult?>(null)
        private set

    init {
        viewModelScope.launch {
            repo.state.collect {
                sfx.enabled = it.soundOn
                speaker.enabled = it.voiceOn
            }
        }
    }

    fun finishGame(stars: Int, coins: Int) {
        lastResult = GameResult(stars, coins)
        viewModelScope.launch { repo.addReward(stars, coins) }
    }

    fun markIntroSeen() { viewModelScope.launch { repo.setIntroSeen() } }
    fun setAge(age: Int) { viewModelScope.launch { repo.setAge(age) } }
    fun setSound(on: Boolean) { viewModelScope.launch { repo.setSound(on) } }
    fun setVoice(on: Boolean) { viewModelScope.launch { repo.setVoice(on) } }
    fun setReduceMotion(on: Boolean) { viewModelScope.launch { repo.setReduceMotion(on) } }
    fun resetProgress() { viewModelScope.launch { repo.resetProgress() } }

    override fun onCleared() {
        speaker.shutdown()
        sfx.release()
        super.onCleared()
    }
}
