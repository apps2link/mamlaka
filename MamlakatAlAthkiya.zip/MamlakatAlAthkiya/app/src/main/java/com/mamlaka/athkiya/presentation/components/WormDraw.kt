package com.mamlaka.athkiya.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix
import kotlin.math.sin

val WormColors = listOf(
    Color(0xFF9B6BFF), Color(0xFFFF6FA5), Color(0xFF4FC3F7), Color(0xFF66BB6A), Color(0xFFFFA726),
)

/** A cartoon worm filling the canvas, head on the right. [accessory]: 0 top hat, 1 glasses, 2 none. */
fun DrawScope.drawWorm(color: Color, accessory: Int) {
    val w = size.width
    val h = size.height
    val r = h * 0.30f
    val count = maxOf(3, (w / (r * 1.1f)).toInt())
    val light = color.mix(Color.White, 0.28f)
    var headCenter = Offset(w - r, h / 2f)
    for (i in 0 until count) {
        val t = i / (count - 1f)
        val x = r + t * (w - 2f * r)
        val y = h / 2f + sin(t * Math.PI * 3.0).toFloat() * h * 0.10f
        drawCircle(if (i % 2 == 0) color else light, r, Offset(x, y))
        if (i == count - 1) headCenter = Offset(x, y)
    }
    val hc = headCenter
    for (s in listOf(-1f, 1f)) {
        drawCircle(Color.White, r * 0.26f, Offset(hc.x + s * r * 0.36f, hc.y - r * 0.18f))
        drawCircle(Palette.Ink, r * 0.13f, Offset(hc.x + s * r * 0.36f + r * 0.05f, hc.y - r * 0.18f))
    }
    drawArc(Palette.Ink, 20f, 140f, false, Offset(hc.x - r * 0.3f, hc.y - r * 0.05f), Size(r * 0.6f, r * 0.45f), style = Stroke(r * 0.09f, cap = StrokeCap.Round))
    when (accessory) {
        0 -> {
            drawRect(Palette.Ink, Offset(hc.x - r * 0.35f, hc.y - r * 1.25f), Size(r * 0.7f, r * 0.55f))
            drawRect(Palette.Ink, Offset(hc.x - r * 0.6f, hc.y - r * 0.75f), Size(r * 1.2f, r * 0.12f))
            drawRect(Palette.Pink, Offset(hc.x - r * 0.35f, hc.y - r * 0.85f), Size(r * 0.7f, r * 0.1f))
        }
        1 -> for (s in listOf(-1f, 1f)) {
            drawCircle(Color(0xFF2E7D32), r * 0.32f, Offset(hc.x + s * r * 0.36f, hc.y - r * 0.18f), style = Stroke(r * 0.08f))
        }
        else -> Unit
    }
}

@Composable
fun WormIcon(color: Color, accessory: Int, width: Dp, height: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width, height)) { drawWorm(color, accessory) }
}
