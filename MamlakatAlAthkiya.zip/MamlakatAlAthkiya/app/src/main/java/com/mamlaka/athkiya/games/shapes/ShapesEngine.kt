package com.mamlaka.athkiya.games.shapes

import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.presentation.components.ShapeKind
import kotlin.random.Random

enum class ShapeMode { NAME, PICK }

/** NAME: a shape is shown, pick its name. PICK: a name is given, pick the shape. */
data class ShapeRound(val target: ShapeKind, val mode: ShapeMode, val options: List<ShapeKind>)

object ShapesEngine {
    const val ROUNDS = 6

    fun pool(level: GameLevel): List<ShapeKind> = when (level) {
        GameLevel.EASY -> listOf(ShapeKind.CIRCLE, ShapeKind.SQUARE, ShapeKind.TRIANGLE)
        GameLevel.MEDIUM -> listOf(ShapeKind.CIRCLE, ShapeKind.SQUARE, ShapeKind.TRIANGLE, ShapeKind.RECTANGLE, ShapeKind.DIAMOND)
        GameLevel.HARD -> ShapeKind.entries
    }

    fun optionCount(level: GameLevel) = if (level == GameLevel.HARD) 4 else 3

    fun build(level: GameLevel, random: Random = Random.Default): List<ShapeRound> {
        val pool = pool(level)
        val targets = (pool.shuffled(random) + pool.shuffled(random)).take(ROUNDS)
        return targets.mapIndexed { i, target ->
            val mode = when (level) {
                GameLevel.EASY -> ShapeMode.NAME
                GameLevel.MEDIUM -> if (i % 2 == 0) ShapeMode.NAME else ShapeMode.PICK
                GameLevel.HARD -> if (random.nextBoolean()) ShapeMode.NAME else ShapeMode.PICK
            }
            val others = pool.filter { it != target }.shuffled(random).take(optionCount(level) - 1)
            ShapeRound(target, mode, (others + target).shuffled(random))
        }
    }
}
