package com.mamlaka.athkiya.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette

/** Parent dashboard: child's age, sound / speech / motion settings, progress summary, confirmed reset. */
@Composable
fun ParentScreen(vm: AppViewModel, state: GameState, onBack: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }

    ScreenScaffold {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            TopBar(onBack = onBack)
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(stringResource(R.string.parent_title), style = MamlakaType.Display, color = Palette.Purple, modifier = Modifier.fillMaxWidth())

                Panel {
                    Text(stringResource(R.string.child_age), style = MamlakaType.Title, color = Palette.Ink)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (age in 3..6) {
                            BigButton(
                                text = age.toArabicDigits(),
                                color = if (state.age == age) Palette.Orange else Palette.Blue.copy(alpha = 0.55f),
                                modifier = Modifier.weight(1f),
                            ) { vm.setAge(age) }
                        }
                    }
                    Text(
                        stringResource(R.string.age_years, state.age.toArabicDigits()),
                        style = MamlakaType.Body,
                        color = Palette.Ink,
                    )
                }

                Panel {
                    SwitchRow(stringResource(R.string.sfx_label), state.soundOn) { vm.setSound(it) }
                    SwitchRow(stringResource(R.string.voice_label), state.voiceOn) { vm.setVoice(it) }
                    if (!vm.speaker.arabicAvailable) {
                        Text(stringResource(R.string.no_arabic_voice), style = MamlakaType.Body.copy(fontSize = 16.sp), color = Palette.Coral)
                    }
                    SwitchRow(stringResource(R.string.reduce_motion_label), state.reduceMotion) { vm.setReduceMotion(it) }
                }

                Panel {
                    Text(stringResource(R.string.progress_title), style = MamlakaType.Title, color = Palette.Ink)
                    StatRow(stringResource(R.string.stars_label), state.stars)
                    StatRow(stringResource(R.string.coins_label), state.coins)
                    StatRow(stringResource(R.string.sessions_label), state.sessionsCompleted)
                    BigButton(stringResource(R.string.reset_progress), Palette.Coral, Modifier.fillMaxWidth()) { confirmReset = true }
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(stringResource(R.string.reset_confirm_title)) },
            text = { Text(stringResource(R.string.reset_confirm_text)) },
            confirmButton = {
                TextButton(onClick = { vm.resetProgress(); confirmReset = false }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White.copy(alpha = 0.94f), RoundedCornerShape(28.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) { content() }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MamlakaType.Body, color = Palette.Ink, textAlign = TextAlign.Start, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StatRow(label: String, value: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MamlakaType.Body, color = Palette.Ink)
        Text(value.toArabicDigits(), style = MamlakaType.Body, color = Palette.Purple)
    }
}
