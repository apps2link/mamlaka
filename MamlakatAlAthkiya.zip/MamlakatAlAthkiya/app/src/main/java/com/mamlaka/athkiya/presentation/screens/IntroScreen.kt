package com.mamlaka.athkiya.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.LocalReduceMotion
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.characters.Mood
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.SpeechBubble
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlinx.coroutines.delay

/**
 * Short opening scene: a child walks up to the castle gate, and Lulu welcomes them.
 */
@Composable
fun IntroScreen(onSpeak: (String) -> Unit, onDone: () -> Unit) {
    val reduce = LocalReduceMotion.current
    val line = stringResource(R.string.intro_line)
    val walk = remember { Animatable(0f) }
    var showGuide by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (reduce) walk.snapTo(1f) else walk.animateTo(1f, tween(2200, easing = FastOutSlowInEasing))
        showGuide = true
        delay(300)
        onSpeak(line)
    }

    ScreenScaffold {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // scene: castle + child walking toward the gate
            Box(Modifier.fillMaxWidth().height(260.dp)) {
                Canvas(Modifier.fillMaxSize()) {
                    drawCastle()
                    val t = walk.value
                    val childX = size.width * (0.05f + 0.40f * t)
                    drawChild(Offset(childX, size.height * 0.88f), size.height * 0.36f, step = t)
                }
            }

            AnimatedVisibility(
                visible = showGuide,
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Mascot(MascotKind.LULU, Modifier.size(140.dp), mood = Mood.CHEER, action = MascotAction.WAVE)
                    SpeechBubble(line, Modifier.weight(1f))
                }
            }

            AnimatedVisibility(visible = showGuide, enter = fadeIn()) {
                BigButton(stringResource(R.string.intro_go), Palette.Orange, Modifier.fillMaxWidth(), onClick = onDone)
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCastle() {
    val w = size.width
    val h = size.height
    val wall = Color(0xFFF3E5FF)
    val dark = Color(0xFFB28DFF)
    // main wall + towers
    drawRoundRect(wall, Offset(w * 0.52f, h * 0.38f), Size(w * 0.42f, h * 0.55f), CornerRadius(12f))
    drawRoundRect(wall, Offset(w * 0.50f, h * 0.22f), Size(w * 0.10f, h * 0.71f), CornerRadius(10f))
    drawRoundRect(wall, Offset(w * 0.86f, h * 0.22f), Size(w * 0.10f, h * 0.71f), CornerRadius(10f))
    for (x in listOf(0.55f, 0.91f)) {
        val roof = Path().apply {
            moveTo(w * (x - 0.07f), h * 0.23f)
            lineTo(w * x, h * 0.02f)
            lineTo(w * (x + 0.07f), h * 0.23f)
            close()
        }
        drawPath(roof, Palette.Pink)
    }
    // gate
    drawRoundRect(dark, Offset(w * 0.67f, h * 0.60f), Size(w * 0.10f, h * 0.33f), CornerRadius(40f))
    // windows
    for (x in listOf(0.545f, 0.905f)) drawCircle(Palette.Sun, w * 0.016f, Offset(w * x, h * 0.42f))
    drawCircle(Palette.Sun, w * 0.016f, Offset(w * 0.62f, h * 0.50f))
    drawCircle(Palette.Sun, w * 0.016f, Offset(w * 0.82f, h * 0.50f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawChild(feet: Offset, height: Float, step: Float) {
    val head = height * 0.22f
    val bob = if (step < 1f) kotlin.math.abs(kotlin.math.sin(step * 30f)) * height * 0.04f else 0f
    val base = feet.copy(y = feet.y - bob)
    // legs
    drawLine(Palette.Ink, Offset(base.x - head * 0.35f, base.y), Offset(base.x - head * 0.35f, base.y - height * 0.28f), strokeWidth = head * 0.35f)
    drawLine(Palette.Ink, Offset(base.x + head * 0.35f, base.y), Offset(base.x + head * 0.35f, base.y - height * 0.28f), strokeWidth = head * 0.35f)
    // body
    drawRoundRect(Palette.Blue, Offset(base.x - head * 0.8f, base.y - height * 0.72f), Size(head * 1.6f, height * 0.48f), CornerRadius(head * 0.5f))
    // head + hair
    val headCenter = Offset(base.x, base.y - height * 0.84f)
    drawCircle(Color(0xFFFFD7B5), head, headCenter)
    drawArc(Color(0xFF5B3A29), 180f, 180f, true, Offset(headCenter.x - head, headCenter.y - head), Size(head * 2f, head * 1.4f))
    drawCircle(Palette.Ink, head * 0.1f, Offset(headCenter.x - head * 0.35f, headCenter.y + head * 0.1f))
    drawCircle(Palette.Ink, head * 0.1f, Offset(headCenter.x + head * 0.35f, headCenter.y + head * 0.1f))
}
