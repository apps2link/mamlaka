package com.mamlaka.athkiya.domain

import androidx.annotation.StringRes
import com.mamlaka.athkiya.R

/** The seven worlds of the kingdom. [available] is true once the world has playable games. */
enum class World(val id: String, @StringRes val title: Int, val available: Boolean) {
    LETTERS("letters", R.string.world_letters, true),
    NUMBERS("numbers", R.string.world_numbers, true),
    ANIMALS("animals", R.string.world_animals, false),
    COLORS("colors", R.string.world_colors, true),
    FOREST("forest", R.string.world_forest, true),
    SOUNDS("sounds", R.string.world_sounds, false),
    LIFE("life", R.string.world_life, false);

    companion object {
        fun fromId(id: String?): World? = entries.firstOrNull { it.id == id }
    }
}
