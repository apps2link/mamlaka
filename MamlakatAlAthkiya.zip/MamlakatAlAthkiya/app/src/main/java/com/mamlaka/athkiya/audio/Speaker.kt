package com.mamlaka.athkiya.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/**
 * Arabic speech through the device's TextToSpeech engine (fallback until recorded voice files are added).
 * An Arabic voice is NOT guaranteed to be installed, so [arabicAvailable] is exposed to the UI.
 */
class Speaker(context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    var arabicAvailable by mutableStateOf(false)
        private set
    var enabled: Boolean = true

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("ar"))
                arabicAvailable = result != null &&
                    result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setSpeechRate(0.85f)
                tts?.setPitch(1.1f)
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (!enabled || !ready || !arabicAvailable) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mamlaka_utterance")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
