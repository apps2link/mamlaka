package com.mamlaka.athkiya.core

/** Arabic number words 0..20 for speech (counting aloud, clock phrases). */
object NumberWords {
    private val words = listOf(
        "صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة",
        "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر", "عشرون",
    )

    fun of(n: Int): String = words.getOrElse(n) { n.toString() }

    /** Spoken form of a clock time, e.g. "سبعة والنصف", "ثمانية إلا ربع". [hour] is 1..12. */
    fun clockPhrase(hour: Int, minute: Int): String {
        val h = ((hour - 1).mod(12)) + 1
        val next = (h % 12) + 1
        return when (minute) {
            0 -> "الساعة ${of(h)}"
            15 -> "الساعة ${of(h)} والربع"
            30 -> "الساعة ${of(h)} والنصف"
            45 -> "الساعة ${of(next)} إلا ربع"
            else -> "الساعة ${of(h)} و${minuteWords(minute)}"
        }
    }

    private fun minuteWords(m: Int): String = when (m) {
        5 -> "خمس دقائق"
        10 -> "عشر دقائق"
        20 -> "عشرون دقيقة"
        else -> if (m <= 20) "${of(m)} دقيقة" else "$m دقيقة"
    }
}
