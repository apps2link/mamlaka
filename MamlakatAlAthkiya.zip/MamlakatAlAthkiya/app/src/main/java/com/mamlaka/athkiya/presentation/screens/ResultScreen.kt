package com.mamlaka.athkiya.presentation.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.LocalReduceMotion
import com.mamlaka.athkiya.animations.StarBurst
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.characters.Mood
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.domain.GameResult
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.CoinIcon
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.StarIcon
import com.mamlaka.athkiya.presentation.components.StatsBar
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlinx.coroutines.delay

@Composable
fun ResultScreen(
    result: GameResult?,
    state: GameState,
    onAgain: () -> Unit,
    onMap: () -> Unit,
) {
    val r = result ?: GameResult(stars = 1, coins = 1)
    var burst by remember { mutableIntStateOf(0) }
    val reduce = LocalReduceMotion.current
    LaunchedEffect(Unit) {
        delay(if (reduce) 0L else 400L)
        burst++
    }
    ScreenScaffold {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            TopBar(onBack = null) { StatsBar(state.stars, state.coins) }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                        Mascot(MascotKind.ZIZO, Modifier.size(110.dp), Mood.CHEER, MascotAction.JUMP)
                        Mascot(MascotKind.LULU, Modifier.size(130.dp), Mood.CHEER, MascotAction.JUMP)
                        Mascot(MascotKind.TOTO, Modifier.size(110.dp), Mood.CHEER, MascotAction.JUMP)
                    }
                    Text(stringResource(R.string.result_title), style = MamlakaType.Display, color = Palette.Purple)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in 0 until 3) AnimatedStar(index = i, filled = i < r.stars)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CoinIcon(36.dp)
                        Text(stringResource(R.string.coins_earned, r.coins.toArabicDigits()), style = MamlakaType.Title, color = Palette.Ink)
                    }
                    if (r.points > 0) {
                        Text(stringResource(R.string.points_earned, r.points.toArabicDigits()), style = MamlakaType.Title, color = Palette.Purple)
                    }
                }
                StarBurst(trigger = burst, modifier = Modifier.fillMaxSize())
            }
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                BigButton(stringResource(R.string.play_again), Palette.Orange, Modifier.fillMaxWidth(), onClick = onAgain)
                BigButton(stringResource(R.string.to_map), Palette.Purple, Modifier.fillMaxWidth(), onClick = onMap)
            }
        }
    }
}

@Composable
private fun AnimatedStar(index: Int, filled: Boolean) {
    val reduce = LocalReduceMotion.current
    var shown by remember { mutableStateOf(reduce) }
    LaunchedEffect(Unit) {
        if (!reduce) delay(300L + index * 350L)
        shown = true
    }
    val scale by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "starPop",
    )
    StarIcon(size = 84.dp, filled = filled, modifier = Modifier.scale(scale))
}
