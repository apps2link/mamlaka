package com.mamlaka.athkiya.games.length

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.Canvas
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.games.common.StageCard
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.components.WormColors
import com.mamlaka.athkiya.presentation.components.drawWorm

/** Worms of different lengths: tap the longest (or the shortest) one. */
@Composable
fun LengthGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { LengthEngine.build(level) }
    val prompts = rounds.map { stringResource(if (it.ask == LengthAsk.LONGEST) R.string.q_longest else R.string.q_shortest) }

    GameShell(vm, GameId.LENGTH, level, theme, rounds, prompts, onFinished, onBack) { round, control ->
        // worms are always drawn left-to-right so "longer" reads the same on every device
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            StageCard(Modifier.weight(1f)) {
                Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.SpaceEvenly,
                ) {
                    round.lengths.forEachIndexed { index, fraction ->
                        val color = WormColors[round.colors[index] % WormColors.size]
                        Box(Modifier.fillMaxWidth().height(64.dp), contentAlignment = Alignment.CenterStart) {
                            Canvas(
                                Modifier
                                    .fillMaxWidth(fraction)
                                    .height(64.dp)
                                    .alpha(if (control.locked && index != round.target) 0.45f else 1f)
                                    .bouncyClickable { control.answer(index == round.target, null) },
                            ) { drawWorm(color, round.colors[index] % 3) }
                        }
                    }
                }
            }
        }
    }
}
