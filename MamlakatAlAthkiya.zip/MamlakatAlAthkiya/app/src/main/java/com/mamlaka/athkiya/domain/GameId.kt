package com.mamlaka.athkiya.domain

import androidx.annotation.StringRes
import com.mamlaka.athkiya.R

/** Catalog of the leveled mini-games (the letters game keeps its own screen). */
enum class GameId(val key: String, @StringRes val title: Int, val world: World) {
    COUNTING("counting", R.string.game_counting, World.NUMBERS),
    COMPARISON("comparison", R.string.game_comparison, World.NUMBERS),
    EGGS("eggs", R.string.game_eggs, World.NUMBERS),
    CLOCK("clock", R.string.game_clock, World.NUMBERS),
    SHAPES("shapes", R.string.game_shapes, World.COLORS),
    LENGTH("length", R.string.game_length, World.FOREST);

    companion object {
        fun fromKey(key: String?): GameId? = entries.firstOrNull { it.key == key }
    }
}
