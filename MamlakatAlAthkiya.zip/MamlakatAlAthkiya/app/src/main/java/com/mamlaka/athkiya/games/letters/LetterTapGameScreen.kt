package com.mamlaka.athkiya.games.letters

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.StarBurst
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.animations.shake
import com.mamlaka.athkiya.audio.Sound
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.characters.Mood
import com.mamlaka.athkiya.domain.ArabicLetter
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.RoundButton
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.SpeakerIcon
import com.mamlaka.athkiya.presentation.components.SpeechBubble
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val TileColors = listOf(Palette.Purple, Palette.Orange, Palette.Green, Palette.Pink)

/** "Tap the right letter": hear the letter's name, pick it from big tiles. Wrong taps are gentle and can be retried. */
@Composable
fun LetterTapGameScreen(vm: AppViewModel, onFinished: () -> Unit, onBack: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val rounds = remember { LetterTapEngine.buildRounds(state.age) }

    var index by remember { mutableIntStateOf(0) }
    var mistakes by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var mood by remember { mutableStateOf(Mood.THINKING) }
    var burst by remember { mutableIntStateOf(0) }
    var wrongLetter by remember { mutableStateOf<ArabicLetter?>(null) }
    var shakes by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    val round = rounds[index]
    val prompt = stringResource(R.string.find_letter, round.target.name)

    // read the question aloud at the start of every round
    LaunchedEffect(index) {
        delay(350)
        vm.speaker.speak(prompt)
    }

    fun onPick(letter: ArabicLetter) {
        if (locked) return
        if (letter == round.target) {
            locked = true
            mood = Mood.CHEER
            burst++
            vm.sfx.play(Sound.CORRECT)
            vm.speaker.speak("برافو! ده حرف ال${letter.name}! ${letter.name} ${letter.word}")
            scope.launch {
                delay(2300)
                if (index == rounds.lastIndex) {
                    vm.finishGame(LetterTapEngine.starsFor(mistakes), LetterTapEngine.coinsFor(mistakes))
                    vm.sfx.play(Sound.WIN)
                    onFinished()
                } else {
                    index++
                    locked = false
                    wrongLetter = null
                    mood = Mood.THINKING
                }
            }
        } else {
            mistakes++
            wrongLetter = letter
            shakes++
            mood = Mood.SAD
            vm.sfx.play(Sound.WRONG)
            vm.speaker.speak("حاول تاني!")
            scope.launch {
                delay(900)
                if (!locked) mood = Mood.THINKING
            }
        }
    }

    ScreenScaffold {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TopBar(onBack = onBack) { ProgressDots(total = rounds.size, done = index) }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mascot(
                    MascotKind.ZIZO,
                    Modifier.size(120.dp),
                    mood = mood,
                    action = if (mood == Mood.CHEER) MascotAction.JUMP else MascotAction.IDLE,
                )
                SpeechBubble(prompt, Modifier.weight(1f))
                RoundButton(Palette.Blue, onClick = { vm.speaker.speak(prompt) }) { SpeakerIcon() }
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    round.options.chunked(2).forEachIndexed { rowIndex, rowOptions ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            rowOptions.forEachIndexed { colIndex, option ->
                                LetterTile(
                                    letter = option,
                                    color = TileColors[(rowIndex * 2 + colIndex) % TileColors.size],
                                    dimmed = locked && option != round.target,
                                    shakeTrigger = if (wrongLetter == option) shakes else 0,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onPick(option) },
                                )
                            }
                            if (rowOptions.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                StarBurst(trigger = burst, modifier = Modifier.fillMaxSize())
            }
        }
    }
}

@Composable
private fun LetterTile(
    letter: ArabicLetter,
    color: Color,
    dimmed: Boolean,
    shakeTrigger: Int,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(36.dp)
    Box(
        modifier
            .height(150.dp)
            .shake(shakeTrigger)
            .alpha(if (dimmed) 0.4f else 1f)
            .bouncyClickable(onClick)
            .shadow(8.dp, shape)
            .background(Brush.verticalGradient(listOf(color.mix(Color.White, 0.25f), color)), shape)
            .border(4.dp, Color.White.copy(alpha = 0.7f), shape),
        contentAlignment = Alignment.Center,
    ) {
        Text(letter.ch, style = MamlakaType.Letter, color = Color.White)
    }
}

@Composable
private fun ProgressDots(total: Int, done: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until total) {
            Box(
                Modifier
                    .size(if (i == done) 18.dp else 14.dp)
                    .background(if (i < done) Palette.Sun else Color.White.copy(alpha = 0.8f), CircleShape)
                    .border(2.dp, Palette.GoldDark.copy(alpha = if (i <= done) 1f else 0.3f), CircleShape)
            )
        }
    }
}
