package com.mamlaka.athkiya.domain

/**
 * One Arabic letter.
 * [ch] the glyph, [name] the letter's name (ألف، باء…), [word] a simple word that starts with it.
 * The letter NAME is kept separate from its SOUND on purpose; sounds are added with the audio pack.
 */
data class ArabicLetter(val id: String, val ch: String, val name: String, val word: String)

object ArabicLetters {
    val all: List<ArabicLetter> = listOf(
        ArabicLetter("alif", "أ", "ألف", "أرنب"),
        ArabicLetter("baa", "ب", "باء", "بطة"),
        ArabicLetter("taa", "ت", "تاء", "تفاحة"),
        ArabicLetter("thaa", "ث", "ثاء", "ثعلب"),
        ArabicLetter("jeem", "ج", "جيم", "جمل"),
        ArabicLetter("haa", "ح", "حاء", "حصان"),
        ArabicLetter("khaa", "خ", "خاء", "خروف"),
        ArabicLetter("dal", "د", "دال", "دب"),
        ArabicLetter("dhal", "ذ", "ذال", "ذرة"),
        ArabicLetter("raa", "ر", "راء", "رمان"),
        ArabicLetter("zay", "ز", "زاي", "زرافة"),
        ArabicLetter("seen", "س", "سين", "سمكة"),
        ArabicLetter("sheen", "ش", "شين", "شمس"),
        ArabicLetter("saad", "ص", "صاد", "صقر"),
        ArabicLetter("daad", "ض", "ضاد", "ضفدع"),
        ArabicLetter("taa2", "ط", "طاء", "طائرة"),
        ArabicLetter("zaa", "ظ", "ظاء", "ظرف"),
        ArabicLetter("ayn", "ع", "عين", "عصفور"),
        ArabicLetter("ghayn", "غ", "غين", "غراب"),
        ArabicLetter("faa", "ف", "فاء", "فيل"),
        ArabicLetter("qaf", "ق", "قاف", "قمر"),
        ArabicLetter("kaf", "ك", "كاف", "كلب"),
        ArabicLetter("lam", "ل", "لام", "ليمونة"),
        ArabicLetter("meem", "م", "ميم", "موزة"),
        ArabicLetter("noon", "ن", "نون", "نمر"),
        ArabicLetter("haa2", "ه", "هاء", "هلال"),
        ArabicLetter("waw", "و", "واو", "وردة"),
        ArabicLetter("yaa", "ي", "ياء", "يد"),
    )
}
