package com.mamlaka.athkiya.presentation.screens

import androidx.compose.ui.graphics.Color
import com.mamlaka.athkiya.domain.World
import com.mamlaka.athkiya.presentation.theme.Palette

fun World.color(): Color = when (this) {
    World.LETTERS -> Palette.Purple
    World.NUMBERS -> Palette.Orange
    World.ANIMALS -> Palette.Green
    World.COLORS -> Palette.Pink
    World.FOREST -> Palette.Teal
    World.SOUNDS -> Palette.Blue
    World.LIFE -> Palette.Coral
}
