package com.mamlaka.athkiya.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.runtime.staticCompositionLocalOf
import com.mamlaka.athkiya.R

enum class Sound { TAP, CORRECT, WRONG, WIN }

/** Short original sound effects (res/raw), played with SoundPool at a gentle fixed volume. */
class Sfx(context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val ids: Map<Sound, Int> = mapOf(
        Sound.TAP to pool.load(context, R.raw.sfx_tap, 1),
        Sound.CORRECT to pool.load(context, R.raw.sfx_correct, 1),
        Sound.WRONG to pool.load(context, R.raw.sfx_wrong, 1),
        Sound.WIN to pool.load(context, R.raw.sfx_win, 1),
    )

    var enabled: Boolean = true

    fun play(sound: Sound) {
        if (!enabled) return
        ids[sound]?.let { pool.play(it, 0.6f, 0.6f, 1, 0, 1f) }
    }

    fun release() = pool.release()
}

val LocalSfx = staticCompositionLocalOf<Sfx?> { null }
