package com.mamlaka.athkiya.core

/** Converts Western digits to Arabic-Indic digits (٠١٢٣…) for display. */
fun Int.toArabicDigits(): String = toString().map { ch ->
    if (ch in '0'..'9') '٠' + (ch - '0') else ch
}.joinToString("")
