package com.mamlaka.athkiya.games.numbers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.characters.ThingIcon
import com.mamlaka.athkiya.core.NumberWords
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.games.common.Grid
import com.mamlaka.athkiya.games.common.NumberOptions
import com.mamlaka.athkiya.games.common.StageCard
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.theme.MamlakaType

/** Count the items (touching each one counts it aloud), then pick the number. */
@Composable
fun CountingGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { CountingEngine.build(level) }
    val prompts = rounds.map { stringResource(R.string.q_count, stringResource(it.thing.plural)) }

    GameShell(vm, GameId.COUNTING, level, theme, rounds, prompts, onFinished, onBack) { round, control ->
        val counted = remember(round) { mutableStateListOf<Int>() }
        StageCard(Modifier.weight(1f)) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Grid(items = List(round.count) { it }, perRow = 5, spacing = 8) { index, _ ->
                    val order = counted.indexOf(index)
                    Box(
                        Modifier
                            .size(62.dp)
                            .bouncyClickable {
                                if (index !in counted) {
                                    counted.add(index)
                                    vm.speaker.speak(NumberWords.of(counted.size))
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        ThingIcon(round.thing, 58.dp)
                        if (order >= 0) {
                            Box(
                                Modifier.align(Alignment.TopEnd).size(26.dp).background(theme.accent, CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text((order + 1).toArabicDigits(), style = MamlakaType.Body.copy(fontSize = 15.sp), color = Color.White)
                            }
                        }
                    }
                }
            }
        }
        NumberOptions(round.options, theme.accent, control) { it == round.count }
    }
}
