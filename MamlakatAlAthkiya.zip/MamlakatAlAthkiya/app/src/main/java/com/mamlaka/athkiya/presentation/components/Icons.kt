package com.mamlaka.athkiya.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.animations.starPath
import com.mamlaka.athkiya.domain.World
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette

@Composable
fun StarIcon(size: Dp, filled: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val c = Offset(this.size.width / 2f, this.size.height * 0.54f)
        val outer = this.size.minDimension * 0.5f
        val path = starPath(c, outer, outer * 0.45f)
        drawPath(path, if (filled) Palette.Sun else Color(0x33000000))
        drawPath(path, if (filled) Palette.GoldDark else Color(0x22000000), style = Stroke(width = outer * 0.08f, join = StrokeJoin.Round))
    }
}

@Composable
fun CoinIcon(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val r = this.size.minDimension / 2f
        drawCircle(Palette.GoldDark, r, c)
        drawCircle(Palette.Sun, r * 0.82f, c)
        drawCircle(Palette.GoldDark, r * 0.3f, c)
    }
}

/** Chevron pointing right: "back" in a right-to-left layout. */
@Composable
fun BackIcon(size: Dp = 32.dp, color: Color = Color.White) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val p = Path().apply {
            moveTo(w * 0.35f, h * 0.22f)
            lineTo(w * 0.68f, h * 0.5f)
            lineTo(w * 0.35f, h * 0.78f)
        }
        drawPath(p, color, style = Stroke(width = w * 0.14f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Three sliders: the parent / settings button. */
@Composable
fun SlidersIcon(size: Dp = 32.dp, color: Color = Color.White) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val knobs = listOf(0.7f, 0.35f, 0.6f)
        for (i in 0 until 3) {
            val y = h * (0.25f + i * 0.25f)
            drawLine(color, Offset(w * 0.15f, y), Offset(w * 0.85f, y), strokeWidth = w * 0.09f, cap = StrokeCap.Round)
            drawCircle(color, w * 0.11f, Offset(w * knobs[i], y))
        }
    }
}

@Composable
fun SpeakerIcon(size: Dp = 32.dp, color: Color = Color.White) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val body = Path().apply {
            moveTo(w * 0.12f, h * 0.38f)
            lineTo(w * 0.30f, h * 0.38f)
            lineTo(w * 0.50f, h * 0.20f)
            lineTo(w * 0.50f, h * 0.80f)
            lineTo(w * 0.30f, h * 0.62f)
            lineTo(w * 0.12f, h * 0.62f)
            close()
        }
        drawPath(body, color)
        for (i in 1..2) {
            drawArc(
                color, -45f, 90f, false,
                topLeft = Offset(w * (0.38f - 0.0f * i), h * (0.5f - 0.14f * i)),
                size = Size(w * 0.28f * i, h * 0.28f * i),
                style = Stroke(width = w * 0.07f, cap = StrokeCap.Round),
            )
        }
    }
}

@Composable
fun LockBadge(size: Dp = 30.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        drawCircle(Color.White, w / 2f, Offset(w / 2f, h / 2f))
        drawArc(
            Palette.Ink, 180f, 180f, false,
            topLeft = Offset(w * 0.32f, h * 0.2f), size = Size(w * 0.36f, h * 0.36f),
            style = Stroke(width = w * 0.08f),
        )
        drawRoundRect(
            Palette.Ink, Offset(w * 0.26f, h * 0.42f), Size(w * 0.48f, h * 0.34f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.06f),
        )
    }
}

/** Little drawn emblem for each world (letters and numbers use real glyphs). */
@Composable
fun WorldIcon(world: World, size: Dp) {
    when (world) {
        World.LETTERS -> GlyphIcon("أ", size)
        World.NUMBERS -> GlyphIcon("٣", size)
        else -> Canvas(Modifier.size(size)) {
            val s = this.size.minDimension
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            when (world) {
                World.ANIMALS -> {
                    drawOval(Color.White, Offset(cx - s * 0.2f, cy), Size(s * 0.4f, s * 0.32f))
                    val toes = listOf(Offset(-0.28f, -0.05f), Offset(-0.10f, -0.22f), Offset(0.10f, -0.22f), Offset(0.28f, -0.05f))
                    toes.forEach { drawCircle(Color.White, s * 0.08f, Offset(cx + s * it.x, cy + s * it.y)) }
                }
                World.COLORS -> {
                    drawCircle(Color.White, s * 0.36f, Offset(cx, cy))
                    listOf(Palette.Coral, Palette.Sun, Palette.Green, Palette.Blue).forEachIndexed { i, col ->
                        val a = Math.toRadians(-135.0 + i * 60.0)
                        drawCircle(col, s * 0.07f, Offset(cx + (Math.cos(a) * s * 0.2f).toFloat(), cy + (Math.sin(a) * s * 0.2f).toFloat()))
                    }
                }
                World.FOREST -> {
                    drawRect(Color(0xFF8D5A2B), Offset(cx - s * 0.05f, cy + s * 0.15f), Size(s * 0.1f, s * 0.22f))
                    for (i in 0..1) {
                        val top = cy - s * 0.38f + i * s * 0.2f
                        val tri = Path().apply {
                            moveTo(cx, top)
                            lineTo(cx - s * 0.3f, top + s * 0.36f)
                            lineTo(cx + s * 0.3f, top + s * 0.36f)
                            close()
                        }
                        drawPath(tri, Color.White)
                    }
                }
                World.SOUNDS -> {
                    drawOval(Color.White, Offset(cx - s * 0.30f, cy + s * 0.08f), Size(s * 0.3f, s * 0.22f))
                    drawLine(Color.White, Offset(cx - s * 0.02f, cy + s * 0.18f), Offset(cx - s * 0.02f, cy - s * 0.32f), strokeWidth = s * 0.07f, cap = StrokeCap.Round)
                    drawLine(Color.White, Offset(cx - s * 0.02f, cy - s * 0.32f), Offset(cx + s * 0.28f, cy - s * 0.18f), strokeWidth = s * 0.09f, cap = StrokeCap.Round)
                }
                World.LIFE -> {
                    val heart = Path().apply {
                        moveTo(cx, cy + s * 0.32f)
                        cubicTo(cx - s * 0.6f, cy - s * 0.05f, cx - s * 0.35f, cy - s * 0.5f, cx, cy - s * 0.18f)
                        cubicTo(cx + s * 0.35f, cy - s * 0.5f, cx + s * 0.6f, cy - s * 0.05f, cx, cy + s * 0.32f)
                        close()
                    }
                    drawPath(heart, Color.White)
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun GlyphIcon(glyph: String, size: Dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Text(glyph, style = MamlakaType.Letter.copy(fontSize = (size.value * 0.7f).sp), color = Color.White)
    }
}
