package com.mamlaka.athkiya.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import androidx.compose.ui.res.stringResource

@Composable
fun Crown(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val crown = Path().apply {
            moveTo(w * 0.10f, h * 0.78f)
            lineTo(w * 0.10f, h * 0.30f)
            lineTo(w * 0.32f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.15f)
            lineTo(w * 0.68f, h * 0.52f)
            lineTo(w * 0.90f, h * 0.30f)
            lineTo(w * 0.90f, h * 0.78f)
            close()
        }
        drawPath(crown, Brush.verticalGradient(listOf(Palette.Sun, Palette.Orange)))
        drawRect(Palette.GoldDark, Offset(w * 0.10f, h * 0.82f), Size(w * 0.80f, h * 0.14f))
        drawCircle(Palette.Pink, w * 0.06f, Offset(w * 0.50f, h * 0.62f))
        drawCircle(Palette.Blue, w * 0.045f, Offset(w * 0.27f, h * 0.66f))
        drawCircle(Palette.Green, w * 0.045f, Offset(w * 0.73f, h * 0.66f))
    }
}

/** Game logo: drawn crown over the title, in the kingdom's colors. */
@Composable
fun KingdomLogo(modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Crown(96.dp)
        Text(
            stringResource(R.string.app_name),
            style = MamlakaType.Display.copy(
                shadow = Shadow(color = Palette.Purple, offset = Offset(0f, 6f), blurRadius = 10f),
                fontSize = 46.sp,
            ),
            color = Color.White,
        )
    }
}
