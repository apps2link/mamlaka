package com.mamlaka.athkiya.games.numbers

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.characters.Thing
import com.mamlaka.athkiya.characters.ThingIcon
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.games.common.Grid
import com.mamlaka.athkiya.games.common.StageCard
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.AnswerTile
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.components.Symbol
import com.mamlaka.athkiya.presentation.components.SymbolIcon
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette

/**
 * Compare two groups. Easy/medium: tap the animal of the bigger/smaller group (or "=").
 * Hard adds a symbol question: pick >, = or <.
 */
@Composable
fun ComparisonGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { ComparisonEngine.build(level) }
    val prompts = rounds.map {
        stringResource(
            when (it.type) {
                CmpType.MORE -> R.string.q_more
                CmpType.LESS -> R.string.q_less
                CmpType.SYMBOL -> R.string.q_symbol
            }
        )
    }

    GameShell(vm, GameId.COMPARISON, level, theme, rounds, prompts, onFinished, onBack) { round, control ->
        if (round.type == CmpType.SYMBOL) {
            // symbols are drawn left-to-right so ">" always opens toward the bigger left group
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                StageCard(Modifier.weight(1f)) {
                    Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Group(round.left, round.leftCount, 40.dp, 3) }
                        Text("؟", style = MamlakaType.Display, color = theme.accent)
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Group(round.right, round.rightCount, 40.dp, 3) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(Symbol.GREATER to Choice.LEFT, Symbol.EQUALS to Choice.EQUAL, Symbol.LESS to Choice.RIGHT).forEach { (sym, choice) ->
                        AnswerTile(Modifier.weight(1f), theme.accent, control.locked && choice != round.correct, { control.answer(choice == round.correct, null) }) {
                            SymbolIcon(sym, 64.dp, theme.accent)
                        }
                    }
                }
            }
        } else {
            val size = if (level == GameLevel.EASY) 56.dp else 46.dp
            StageCard(Modifier.weight(1f)) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Group(round.left, round.leftCount, size, 5) }
                Canvas(Modifier.fillMaxWidth().height(4.dp)) {
                    drawLine(
                        Color(0x33000000), Offset(0f, this.size.height / 2f), Offset(this.size.width, this.size.height / 2f),
                        strokeWidth = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 14f)),
                    )
                }
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Group(round.right, round.rightCount, size, 5) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AnswerTile(Modifier.weight(1f), theme.accent, control.locked && round.correct != Choice.LEFT, { control.answer(round.correct == Choice.LEFT, null) }) {
                    ThingIcon(round.left, 72.dp)
                }
                AnswerTile(Modifier.weight(1f), theme.accent, control.locked && round.correct != Choice.EQUAL, { control.answer(round.correct == Choice.EQUAL, null) }) {
                    SymbolIcon(Symbol.EQUALS, 64.dp, theme.accent)
                }
                AnswerTile(Modifier.weight(1f), theme.accent, control.locked && round.correct != Choice.RIGHT, { control.answer(round.correct == Choice.RIGHT, null) }) {
                    ThingIcon(round.right, 72.dp)
                }
            }
        }
    }
}

@Composable
private fun Group(thing: Thing, count: Int, size: Dp, perRow: Int) {
    Grid(items = List(count) { it }, perRow = perRow, spacing = 4) { _, _ -> ThingIcon(thing, size) }
}
