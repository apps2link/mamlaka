package com.mamlaka.athkiya.characters

import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.starPath
import com.mamlaka.athkiya.presentation.theme.Palette

/** Cartoon things used as countable items. [plural] is the definite plural, ready to speak. */
enum class Thing(@StringRes val plural: Int) {
    FROG(R.string.plural_frog),
    MONKEY(R.string.plural_monkey),
    SHEEP(R.string.plural_sheep),
    CHICK(R.string.plural_chick),
    APPLE(R.string.plural_apple),
    STAR(R.string.plural_star),
    BALL(R.string.plural_ball),
    EGG(R.string.plural_egg),
}

private val Ink = Palette.Ink

private fun DrawScope.eyes(c: Offset, dx: Float, r: Float) {
    for (s in listOf(-1f, 1f)) {
        drawCircle(Color.White, r, Offset(c.x + s * dx, c.y))
        drawCircle(Ink, r * 0.55f, Offset(c.x + s * dx, c.y))
        drawCircle(Color.White, r * 0.2f, Offset(c.x + s * dx + r * 0.15f, c.y - r * 0.2f))
    }
}

private fun DrawScope.smile(c: Offset, w: Float, stroke: Float) {
    drawArc(Ink, 15f, 150f, false, Offset(c.x - w / 2f, c.y - w * 0.35f), Size(w, w * 0.7f), style = Stroke(stroke, cap = StrokeCap.Round))
}

/** Draws [thing] centred at [c], fitting inside a square of side [s]. */
fun DrawScope.drawThing(thing: Thing, c: Offset, s: Float) {
    when (thing) {
        Thing.FROG -> {
            val green = Color(0xFF6FCF3E)
            val dark = Color(0xFF4FA82A)
            for (sx in listOf(-1f, 1f)) {
                drawOval(dark, Offset(c.x + sx * s * 0.34f - s * 0.12f, c.y + s * 0.30f), Size(s * 0.24f, s * 0.14f))
                drawCircle(green, s * 0.17f, Offset(c.x + sx * s * 0.22f, c.y - s * 0.28f))
            }
            drawOval(green, Offset(c.x - s * 0.45f, c.y - s * 0.30f), Size(s * 0.9f, s * 0.72f))
            drawOval(Color(0xFFD9F5B5), Offset(c.x - s * 0.26f, c.y + s * 0.02f), Size(s * 0.52f, s * 0.36f))
            eyes(Offset(c.x, c.y - s * 0.28f), s * 0.22f, s * 0.11f)
            smile(Offset(c.x, c.y - s * 0.02f), s * 0.34f, s * 0.035f)
        }
        Thing.MONKEY -> {
            val brown = Color(0xFF9C5B2E)
            val tan = Color(0xFFF3C99B)
            for (sx in listOf(-1f, 1f)) {
                drawCircle(brown, s * 0.15f, Offset(c.x + sx * s * 0.40f, c.y - s * 0.05f))
                drawCircle(tan, s * 0.09f, Offset(c.x + sx * s * 0.40f, c.y - s * 0.05f))
            }
            drawCircle(brown, s * 0.40f, Offset(c.x, c.y))
            drawOval(tan, Offset(c.x - s * 0.30f, c.y - s * 0.12f), Size(s * 0.6f, s * 0.48f))
            eyes(Offset(c.x, c.y - s * 0.02f), s * 0.14f, s * 0.07f)
            drawOval(Color(0xFF8B1E3F), Offset(c.x - s * 0.09f, c.y + s * 0.12f), Size(s * 0.18f, s * 0.12f))
        }
        Thing.SHEEP -> {
            val wool = Color.White
            val shade = Color(0xFFE8ECF4)
            for (i in 0 until 7) {
                val a = Math.toRadians(i * 360.0 / 7)
                drawCircle(shade, s * 0.20f, Offset(c.x + (Math.cos(a) * s * 0.27f).toFloat(), c.y + (Math.sin(a) * s * 0.25f).toFloat() - s * 0.03f))
            }
            drawCircle(wool, s * 0.30f, Offset(c.x, c.y - s * 0.04f))
            for (sx in listOf(-1f, 1f)) drawOval(Color(0xFFF2C9A0), Offset(c.x + sx * s * 0.26f - s * 0.07f, c.y + s * 0.0f), Size(s * 0.14f, s * 0.2f))
            drawOval(Color(0xFFFBE3CB), Offset(c.x - s * 0.17f, c.y - s * 0.12f), Size(s * 0.34f, s * 0.42f))
            eyes(Offset(c.x, c.y + s * 0.02f), s * 0.08f, s * 0.045f)
            smile(Offset(c.x, c.y + s * 0.15f), s * 0.14f, s * 0.025f)
        }
        Thing.CHICK -> {
            val yellow = Color(0xFFFFD84D)
            drawCircle(yellow, s * 0.40f, Offset(c.x, c.y + s * 0.02f))
            for (i in -1..1) drawLine(Palette.Orange, Offset(c.x + i * s * 0.05f, c.y - s * 0.36f), Offset(c.x + i * s * 0.12f, c.y - s * 0.48f), s * 0.04f, StrokeCap.Round)
            for (sx in listOf(-1f, 1f)) {
                drawOval(Color(0xFFF2B600), Offset(c.x + sx * s * 0.38f - s * 0.06f, c.y - s * 0.02f), Size(s * 0.12f, s * 0.2f))
                drawLine(Palette.Orange, Offset(c.x + sx * s * 0.12f, c.y + s * 0.4f), Offset(c.x + sx * s * 0.12f, c.y + s * 0.48f), s * 0.035f, StrokeCap.Round)
            }
            eyes(Offset(c.x, c.y - s * 0.06f), s * 0.15f, s * 0.06f)
            val beak = Path().apply {
                moveTo(c.x - s * 0.07f, c.y + s * 0.04f)
                lineTo(c.x + s * 0.07f, c.y + s * 0.04f)
                lineTo(c.x, c.y + s * 0.14f)
                close()
            }
            drawPath(beak, Palette.Orange)
            for (sx in listOf(-1f, 1f)) drawCircle(Palette.Pink.copy(alpha = 0.5f), s * 0.05f, Offset(c.x + sx * s * 0.27f, c.y + s * 0.08f))
        }
        Thing.APPLE -> {
            drawCircle(Color(0xFFE53935), s * 0.36f, Offset(c.x - s * 0.1f, c.y + s * 0.06f))
            drawCircle(Color(0xFFE53935), s * 0.36f, Offset(c.x + s * 0.1f, c.y + s * 0.06f))
            drawCircle(Color.White.copy(alpha = 0.45f), s * 0.07f, Offset(c.x - s * 0.2f, c.y - s * 0.06f))
            drawLine(Color(0xFF6D4C41), Offset(c.x, c.y - s * 0.22f), Offset(c.x + s * 0.03f, c.y - s * 0.38f), s * 0.05f, StrokeCap.Round)
            drawOval(Color(0xFF43A047), Offset(c.x + s * 0.03f, c.y - s * 0.42f), Size(s * 0.22f, s * 0.12f))
        }
        Thing.STAR -> {
            val p = starPath(Offset(c.x, c.y + s * 0.03f), s * 0.46f, s * 0.21f)
            drawPath(p, Palette.Sun)
            drawPath(p, Palette.GoldDark, style = Stroke(s * 0.04f))
        }
        Thing.BALL -> {
            drawCircle(Palette.Blue, s * 0.40f, c)
            drawArc(Color.White, 200f, 140f, false, Offset(c.x - s * 0.40f, c.y - s * 0.40f), Size(s * 0.8f, s * 0.8f), style = Stroke(s * 0.12f))
            drawCircle(Palette.Pink, s * 0.1f, c)
            drawCircle(Color.White.copy(alpha = 0.4f), s * 0.07f, Offset(c.x - s * 0.18f, c.y - s * 0.18f))
        }
        Thing.EGG -> {
            drawOval(Color(0xFFFFF3E0), Offset(c.x - s * 0.30f, c.y - s * 0.40f), Size(s * 0.60f, s * 0.78f))
            drawOval(Color(0xFFE8CDA0), Offset(c.x - s * 0.30f, c.y - s * 0.40f), Size(s * 0.60f, s * 0.78f), style = Stroke(s * 0.03f))
            drawCircle(Color(0xFFE8CDA0), s * 0.04f, Offset(c.x - s * 0.08f, c.y - s * 0.12f))
            drawCircle(Color(0xFFE8CDA0), s * 0.03f, Offset(c.x + s * 0.12f, c.y + s * 0.05f))
            drawCircle(Color(0xFFE8CDA0), s * 0.035f, Offset(c.x - s * 0.1f, c.y + s * 0.16f))
        }
    }
}

@Composable
fun ThingIcon(thing: Thing, size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        drawThing(thing, Offset(this.size.width / 2f, this.size.height / 2f), this.size.minDimension)
    }
}
