package com.mamlaka.athkiya.games.common

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.StarBurst
import com.mamlaka.athkiya.animations.shake
import com.mamlaka.athkiya.audio.Sound
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.characters.Mood
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.letters.LetterTapEngine
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.GameScaffold
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.components.RoundButton
import com.mamlaka.athkiya.presentation.components.SpeakerIcon
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** What a game's content gets from the shell: whether input is locked, and how to report an answer. */
class ShellControl(
    val locked: Boolean,
    val wrongTick: Int,
    /** Report an answer. [extraSpeech] is spoken after a correct one (e.g. the shape's name). */
    val answer: (correct: Boolean, extraSpeech: String?) -> Unit,
)

/** Scoring shared by the leveled games. */
object Scoring {
    fun stars(mistakes: Int): Int = LetterTapEngine.starsFor(mistakes)
    fun coins(rounds: Int, mistakes: Int): Int = (rounds - mistakes).coerceAtLeast(1)
    fun points(rounds: Int, mistakes: Int): Int = (rounds * 10 - mistakes * 4).coerceAtLeast(rounds)
}

/**
 * The common frame of every leveled game: colored backdrop, progress bar, question pill with a replay
 * button, mascot feedback, star burst and shake. The game supplies only its rounds and its play area.
 */
@Composable
fun <R> GameShell(
    vm: AppViewModel,
    game: GameId,
    level: GameLevel,
    theme: GameTheme,
    rounds: List<R>,
    prompts: List<String>,
    onFinished: () -> Unit,
    onBack: () -> Unit,
    spokenPrompts: List<String> = prompts,
    content: @Composable ColumnScope.(R, ShellControl) -> Unit,
) {
    var index by remember { mutableIntStateOf(0) }
    var mistakes by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var mood by remember { mutableStateOf(Mood.THINKING) }
    var burst by remember { mutableIntStateOf(0) }
    var wrongTick by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    val praise = listOf(R.string.praise_1, R.string.praise_2, R.string.praise_3).map { stringResource(it) }
    val tryAgain = stringResource(R.string.try_again)
    val closer = stringResource(R.string.closer)

    LaunchedEffect(index) {
        delay(350)
        vm.speaker.speak(spokenPrompts[index])
    }

    fun answer(correct: Boolean, extraSpeech: String?) {
        if (locked) return
        if (correct) {
            locked = true
            mood = Mood.CHEER
            burst++
            vm.sfx.play(Sound.CORRECT)
            val line = praise[index % praise.size]
            vm.speaker.speak(if (extraSpeech != null) "$extraSpeech! $line" else line)
            scope.launch {
                delay(1900)
                if (index == rounds.lastIndex) {
                    vm.finishGame(
                        Scoring.stars(mistakes),
                        Scoring.coins(rounds.size, mistakes),
                        Scoring.points(rounds.size, mistakes),
                        game.key,
                        level,
                    )
                    vm.sfx.play(Sound.WIN)
                    onFinished()
                } else {
                    index++
                    locked = false
                    mood = Mood.THINKING
                }
            }
        } else {
            mistakes++
            wrongTick++
            mood = Mood.SAD
            vm.sfx.play(Sound.WRONG)
            vm.speaker.speak(if (mistakes % 2 == 0) closer else tryAgain)
            scope.launch {
                delay(900)
                if (!locked) mood = Mood.THINKING
            }
        }
    }

    val progress by animateFloatAsState(
        targetValue = (index + if (locked) 1 else 0) / rounds.size.toFloat(),
        animationSpec = tween(400),
        label = "progress",
    )

    GameScaffold(theme) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TopBar(onBack = onBack) {
                // progress bar, like the reference designs
                Box(
                    Modifier
                        .weight(1f)
                        .padding(start = 16.dp)
                        .height(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.6f))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress.coerceIn(0.04f, 1f))
                            .clip(RoundedCornerShape(12.dp))
                            .background(Palette.Sun)
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mascot(
                    MascotKind.ZIZO,
                    Modifier.size(84.dp),
                    mood = mood,
                    action = if (mood == Mood.CHEER) MascotAction.JUMP else MascotAction.IDLE,
                )
                Box(
                    Modifier
                        .weight(1f)
                        .background(Color.White, RoundedCornerShape(28.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(prompts[index], style = MamlakaType.Body, color = Palette.Ink)
                }
                RoundButton(theme.accent, onClick = { vm.speaker.speak(spokenPrompts[index]) }) { SpeakerIcon() }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                val control = ShellControl(locked, wrongTick, ::answer)
                Column(
                    Modifier.fillMaxSize().shake(wrongTick),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    content(rounds[index], control)
                }
                StarBurst(trigger = burst, modifier = Modifier.fillMaxSize())
            }
        }
    }
}
