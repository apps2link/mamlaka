package com.mamlaka.athkiya.presentation.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.KingdomLogo
import com.mamlaka.athkiya.presentation.components.RoundButton
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.SlidersIcon
import com.mamlaka.athkiya.presentation.components.StatsBar
import com.mamlaka.athkiya.presentation.theme.Palette

@Composable
fun HomeScreen(state: GameState, onPlay: () -> Unit, onParents: () -> Unit) {
    ScreenScaffold {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                StatsBar(state.stars, state.coins)
                // the parent area sits behind a grown-ups-only question
                RoundButton(Palette.Blue, onClick = onParents) { SlidersIcon() }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                KingdomLogo()
            }
            BigButton(stringResource(R.string.play), Palette.Orange, Modifier.fillMaxWidth(0.8f), onClick = onPlay)
            Row(
                Modifier.fillMaxWidth().weight(0.9f),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom,
            ) {
                Mascot(MascotKind.LULU, Modifier.size(120.dp))
                Mascot(MascotKind.ZIZO, Modifier.size(120.dp))
                Mascot(MascotKind.TOTO, Modifier.size(120.dp))
            }
        }
    }
}
