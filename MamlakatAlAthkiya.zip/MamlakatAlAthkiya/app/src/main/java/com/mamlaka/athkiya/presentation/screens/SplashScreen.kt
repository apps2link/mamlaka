package com.mamlaka.athkiya.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.presentation.components.KingdomLogo
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(state: GameState, onDone: (introSeen: Boolean) -> Unit) {
    var appear by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appear = true }
    // wait for saved settings to load, show the logo for a moment, then continue
    LaunchedEffect(state.loaded) {
        if (state.loaded) {
            delay(2000)
            onDone(state.introSeen)
        }
    }
    ScreenScaffold {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            AnimatedVisibility(
                visible = appear,
                enter = scaleIn(initialScale = 0.5f, animationSpec = spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(24.dp)) {
                    KingdomLogo()
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                        Mascot(MascotKind.LULU, Modifier.size(100.dp))
                        Mascot(MascotKind.ZIZO, Modifier.size(100.dp))
                        Mascot(MascotKind.TOTO, Modifier.size(100.dp))
                    }
                }
            }
        }
    }
}
