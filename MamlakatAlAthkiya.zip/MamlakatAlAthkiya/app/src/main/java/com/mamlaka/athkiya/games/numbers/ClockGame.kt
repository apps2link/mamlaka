package com.mamlaka.athkiya.games.numbers

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.core.NumberWords
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.BigButton
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.components.RoundButton
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Learn the clock: set the shown time by dragging either hand around the face, or with the arrows.
 * Easy: full hours. Medium: + half hours. Hard: quarters and five-minute steps.
 */
@Composable
fun ClockGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { ClockEngine.build(level) }
    val prompts = rounds.map { stringResource(R.string.q_clock, it.label) }
    val spoken = rounds.map { "اضبط الساعة على " + NumberWords.clockPhrase(it.hour, it.minute) }

    GameShell(vm, GameId.CLOCK, level, theme, rounds, prompts, onFinished, onBack, spokenPrompts = spoken) { round, control ->
        var hour by remember(round) { mutableIntStateOf(12) }
        var minute by remember(round) { mutableIntStateOf(0) }

        ClockFace(
            hour = hour,
            minute = minute,
            onHour = { hour = it },
            onMinute = { minute = it },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
        DigitalPanel(
            hour = hour,
            minute = minute,
            onHourStep = { up -> hour = if (up) hour % 12 + 1 else (hour + 10) % 12 + 1 },
            onMinuteStep = { up -> minute = if (up) (minute + 5) % 60 else (minute + 55) % 60 },
        )
        BigButton(stringResource(R.string.check_answer), Palette.Green, Modifier.fillMaxWidth()) {
            val ok = round.matches(hour, minute)
            control.answer(ok, if (ok) NumberWords.clockPhrase(round.hour, round.minute) else null)
        }
    }
}

private fun angleOf(dx: Float, dy: Float): Float =
    ((Math.toDegrees(atan2(dx.toDouble(), -dy.toDouble())) + 360.0) % 360.0).toFloat()

@Composable
private fun ClockFace(hour: Int, minute: Int, onHour: (Int) -> Unit, onMinute: (Int) -> Unit, modifier: Modifier) {
    val currentHour by rememberUpdatedState(hour)
    val currentMinute by rememberUpdatedState(minute)
    val hourCallback by rememberUpdatedState(onHour)
    val minuteCallback by rememberUpdatedState(onMinute)

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side: Dp = if (maxWidth < maxHeight) maxWidth else maxHeight
        Box(
            Modifier
                .size(side)
                .pointerInput(Unit) {
                    var active = 0 // 1 = hour hand, 2 = minute hand
                    fun update(pos: Offset) {
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val angle = angleOf(pos.x - c.x, pos.y - c.y)
                        if (active == 2) {
                            onMinuteSnap(angle, minuteCallback)
                        } else if (active == 1) {
                            val h = ((angle - currentMinute * 0.5f) / 30f).roundToInt().mod(12)
                            hourCallback(if (h == 0) 12 else h)
                        }
                    }
                    detectDragGestures(
                        onDragStart = { pos ->
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val w = size.width.toFloat()
                            val minuteAngle = Math.toRadians(currentMinute * 6.0)
                            val hourAngle = Math.toRadians((currentHour % 12 + currentMinute / 60.0) * 30.0)
                            val minuteTip = Offset(c.x + sin(minuteAngle).toFloat() * w * 0.34f, c.y - cos(minuteAngle).toFloat() * w * 0.34f)
                            val hourTip = Offset(c.x + sin(hourAngle).toFloat() * w * 0.24f, c.y - cos(hourAngle).toFloat() * w * 0.24f)
                            active = if ((pos - minuteTip).getDistance() <= (pos - hourTip).getDistance()) 2 else 1
                            update(pos)
                        },
                        onDrag = { change, _ -> update(change.position) },
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            // ears, ring and face
            Canvas(Modifier.size(side)) {
                val s = this.size.minDimension
                val c = Offset(s / 2f, s / 2f)
                for (sx in listOf(-1f, 1f)) {
                    drawCircle(Color(0xFFFFB02E), s * 0.13f, Offset(c.x + sx * s * 0.34f, c.y - s * 0.38f))
                    drawCircle(Color(0xFFFFE08A), s * 0.07f, Offset(c.x + sx * s * 0.34f, c.y - s * 0.38f))
                }
                drawCircle(Color(0xFFFFC857), s * 0.47f, c)
                drawCircle(Color.White, s * 0.42f, c)
                for (i in 0 until 60) {
                    val a = Math.toRadians(i * 6.0)
                    val long = i % 5 == 0
                    val r1 = s * (if (long) 0.375f else 0.395f)
                    val r2 = s * 0.41f
                    drawLine(
                        if (long) Palette.Ink else Color(0x55000000),
                        Offset(c.x + (sin(a) * r1).toFloat(), c.y - (cos(a) * r1).toFloat()),
                        Offset(c.x + (sin(a) * r2).toFloat(), c.y - (cos(a) * r2).toFloat()),
                        strokeWidth = if (long) s * 0.012f else s * 0.006f,
                        cap = StrokeCap.Round,
                    )
                }
            }
            // hour numbers
            val radius = side.value * 0.31f
            for (n in 1..12) {
                val a = Math.toRadians(n * 30.0)
                val dx = (radius * sin(a)).toFloat().dp
                val dy = (-radius * cos(a)).toFloat().dp
                Box(Modifier.offset(x = dx, y = dy).size(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        n.toArabicDigits(),
                        style = MamlakaType.Body.copy(fontSize = (side.value * 0.075f).sp),
                        color = if (n % 3 == 0) Palette.Coral else Palette.Ink,
                    )
                }
            }
            // hands + smiling center
            Canvas(Modifier.size(side)) {
                val s = this.size.minDimension
                val c = Offset(s / 2f, s / 2f)
                val hourAngle = Math.toRadians((hour % 12 + minute / 60.0) * 30.0)
                val minuteAngle = Math.toRadians(minute * 6.0)
                drawLine(
                    Palette.Coral,
                    c,
                    Offset(c.x + (sin(hourAngle) * s * 0.24f).toFloat(), c.y - (cos(hourAngle) * s * 0.24f).toFloat()),
                    strokeWidth = s * 0.045f, cap = StrokeCap.Round,
                )
                drawLine(
                    Palette.Blue,
                    c,
                    Offset(c.x + (sin(minuteAngle) * s * 0.34f).toFloat(), c.y - (cos(minuteAngle) * s * 0.34f).toFloat()),
                    strokeWidth = s * 0.035f, cap = StrokeCap.Round,
                )
                drawCircle(Palette.Ink, s * 0.03f, c)
                drawArc(Palette.Ink, 20f, 140f, false, Offset(c.x - s * 0.05f, c.y + s * 0.03f), Size(s * 0.1f, s * 0.06f), style = Stroke(s * 0.008f, cap = StrokeCap.Round))
            }
        }
    }
}

/** Snap a dragged minute-hand angle to the nearest 5 minutes. */
private fun onMinuteSnap(angle: Float, callback: (Int) -> Unit) {
    callback(((angle / 30f).roundToInt() * 5) % 60)
}

@Composable
private fun DigitalPanel(hour: Int, minute: Int, onHourStep: (Boolean) -> Unit, onMinuteStep: (Boolean) -> Unit) {
    Row(
        Modifier
            .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(28.dp))
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Stepper(hour.toString().padStart(2, '0').toArabicDigits(), Palette.Coral, onHourStep)
        Text(":", style = MamlakaType.Display, color = Palette.Ink)
        Stepper(minute.toString().padStart(2, '0').toArabicDigits(), Palette.Blue, onMinuteStep)
    }
}

@Composable
private fun Stepper(text: String, color: Color, onStep: (Boolean) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        RoundButton(color, Modifier.size(44.dp), onClick = { onStep(true) }) { Chevron(up = true) }
        Text(text, style = MamlakaType.Title.copy(fontSize = 34.sp), color = color)
        RoundButton(color, Modifier.size(44.dp), onClick = { onStep(false) }) { Chevron(up = false) }
    }
}

@Composable
private fun Chevron(up: Boolean) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val y1 = if (up) h * 0.65f else h * 0.35f
        val y2 = if (up) h * 0.35f else h * 0.65f
        drawPath(
            Path().apply { moveTo(w * 0.2f, y1); lineTo(w * 0.5f, y2); lineTo(w * 0.8f, y1) },
            Color.White,
            style = Stroke(width = w * 0.16f, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}
