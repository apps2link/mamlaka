package com.mamlaka.athkiya.games.shapes

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.games.common.GameShell
import com.mamlaka.athkiya.games.common.StageCard
import com.mamlaka.athkiya.games.common.TileRows
import com.mamlaka.athkiya.presentation.AppViewModel
import com.mamlaka.athkiya.presentation.components.AnswerTile
import com.mamlaka.athkiya.presentation.components.GameTheme
import com.mamlaka.athkiya.presentation.components.ShapeIcon
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette

/** Shapes: see a shape and choose its name, or hear a name and choose the shape. The name is spoken on success. */
@Composable
fun ShapesGameScreen(vm: AppViewModel, level: GameLevel, theme: GameTheme, onFinished: () -> Unit, onBack: () -> Unit) {
    val rounds = remember { ShapesEngine.build(level) }
    val prompts = rounds.map {
        if (it.mode == ShapeMode.NAME) stringResource(R.string.q_shape_name)
        else stringResource(R.string.q_shape_pick, stringResource(it.target.label))
    }

    GameShell(vm, GameId.SHAPES, level, theme, rounds, prompts, onFinished, onBack) { round, control ->
        val targetName = stringResource(round.target.label)
        StageCard(Modifier.weight(1f)) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (round.mode == ShapeMode.NAME) {
                    ShapeIcon(round.target, 190.dp)
                } else {
                    Text("ال$targetName", style = MamlakaType.Display.copy(fontSize = 56.sp), color = round.target.color)
                }
            }
        }
        TileRows(round.options) { kind, tileModifier ->
            val correct = kind == round.target
            AnswerTile(
                modifier = tileModifier,
                accent = theme.accent,
                dimmed = control.locked && !correct,
                onClick = { control.answer(correct, if (correct) targetName else null) },
            ) {
                if (round.mode == ShapeMode.NAME) {
                    Text(stringResource(kind.label), style = MamlakaType.Title.copy(fontSize = 32.sp), color = kind.color)
                } else {
                    ShapeIcon(kind, 84.dp)
                }
            }
        }
    }
}
