package com.mamlaka.athkiya.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.animations.shake
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.games.theme
import com.mamlaka.athkiya.presentation.components.GameGlyph
import com.mamlaka.athkiya.presentation.components.GameScaffold
import com.mamlaka.athkiya.presentation.components.LockBadge
import com.mamlaka.athkiya.presentation.components.SpeechBubble
import com.mamlaka.athkiya.presentation.components.StarIcon
import com.mamlaka.athkiya.presentation.components.StatsBar
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlinx.coroutines.delay

/** Easy / medium / hard cards with the best stars earned. A level opens after one star on the previous one. */
@Composable
fun LevelScreen(
    game: GameId,
    state: GameState,
    onSpeak: (String) -> Unit,
    onBack: () -> Unit,
    onPlay: (GameLevel) -> Unit,
) {
    val theme = game.theme()
    val title = stringResource(game.title)
    val hint = stringResource(R.string.level_locked)
    var lockedTaps by remember { mutableIntStateOf(0) }

    GameScaffold(theme) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            TopBar(onBack = onBack) { StatsBar(state.stars, state.coins) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mascot(MascotKind.ZIZO, Modifier.size(100.dp), action = MascotAction.WAVE)
                SpeechBubble("$title: ${stringResource(R.string.level_title)}", Modifier.weight(1f))
            }
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                GameLevel.entries.forEach { level ->
                    val open = state.isLevelOpen(game.key, level)
                    val best = state.best(game.key, level)
                    val shape = RoundedCornerShape(32.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .then(if (!open) Modifier.shake(lockedTaps) else Modifier)
                            .alpha(if (open) 1f else 0.7f)
                            .bouncyClickable {
                                if (open) {
                                    onPlay(level)
                                } else {
                                    lockedTaps++
                                    onSpeak(hint)
                                }
                            }
                            .shadow(8.dp, shape)
                            .background(Color.White, shape)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Box(Modifier.size(80.dp).background(theme.accent.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                            GameGlyph(game, 56.dp)
                            if (!open) Box(Modifier.align(Alignment.BottomEnd)) { LockBadge(28.dp) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(level.title), style = MamlakaType.Title, color = Palette.Ink)
                            if (open) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    for (i in 1..3) StarIcon(32.dp, filled = i <= best)
                                }
                            } else {
                                Text(hint, style = MamlakaType.Body.copy(fontSize = 16.sp), color = Palette.Ink.copy(alpha = 0.7f), textAlign = TextAlign.Start)
                            }
                        }
                    }
                }
            }
        }
    }
}
