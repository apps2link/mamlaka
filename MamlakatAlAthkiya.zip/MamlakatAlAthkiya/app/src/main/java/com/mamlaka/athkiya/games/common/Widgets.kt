package com.mamlaka.athkiya.games.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.presentation.components.AnswerTile
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix

/** Soft white card that holds the play area. */
@Composable
fun StageCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Color.White.copy(alpha = 0.88f), RoundedCornerShape(32.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

/** Big numbered answer tiles (٦ ٧ ٥). */
@Composable
fun NumberOptions(options: List<Int>, accent: Color, control: ShellControl, isCorrect: (Int) -> Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        options.forEach { n ->
            AnswerTile(
                modifier = Modifier.weight(1f),
                accent = accent,
                dimmed = control.locked && !isCorrect(n),
                onClick = { control.answer(isCorrect(n), null) },
            ) {
                Text(n.toArabicDigits(), style = MamlakaType.Letter.copy(fontSize = 52.sp), color = accent.mix(Palette.Ink, 0.3f))
            }
        }
    }
}

/** Lays out [items] in rows of [perRow], left-to-right inside each row. */
@Composable
fun <T> Grid(items: List<T>, perRow: Int, spacing: Int = 6, cell: @Composable (index: Int, item: T) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(spacing.dp)) {
        items.chunked(perRow).forEachIndexed { rowIndex, rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(spacing.dp), verticalAlignment = Alignment.CenterVertically) {
                rowItems.forEachIndexed { col, item -> cell(rowIndex * perRow + col, item) }
            }
        }
    }
}

/** Two-per-row answer layout that keeps tile widths equal when the last row has one tile. */
@Composable
fun <T> TileRows(items: List<T>, tile: @Composable (T, Modifier) -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { tile(it, Modifier.weight(1f)) }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
