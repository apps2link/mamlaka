package com.mamlaka.athkiya.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotAction
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.domain.World
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.SpeechBubble
import com.mamlaka.athkiya.presentation.components.StatsBar
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.components.WorldIcon
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import kotlinx.coroutines.delay

/** Games list of one world. Only worlds with playable games ([World.available]) can be opened from the map. */
@Composable
fun WorldScreen(
    world: World,
    state: GameState,
    onSpeak: (String) -> Unit,
    onBack: () -> Unit,
    onPlayLetterTap: () -> Unit,
) {
    val welcome = stringResource(R.string.world_welcome, stringResource(world.title))
    LaunchedEffect(world) {
        delay(400)
        onSpeak(welcome)
    }
    ScreenScaffold {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            TopBar(onBack = onBack) { StatsBar(state.stars, state.coins) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Mascot(MascotKind.LULU, Modifier.size(120.dp), action = MascotAction.WAVE)
                SpeechBubble(welcome, Modifier.weight(1f))
            }
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                when (world) {
                    World.LETTERS -> GameCard(
                        title = stringResource(R.string.game_tap_letter),
                        color = world.color(),
                        world = world,
                        onClick = onPlayLetterTap,
                    )
                    else -> Unit
                }
            }
        }
    }
}

@Composable
private fun GameCard(title: String, color: Color, world: World, onClick: () -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .bouncyClickable(onClick)
            .shadow(8.dp, shape)
            .background(Color.White, shape)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(Modifier.size(88.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
            WorldIcon(world, 56.dp)
        }
        Text(title, style = MamlakaType.Title, color = Palette.Ink, textAlign = TextAlign.Start, modifier = Modifier.weight(1f))
    }
}
