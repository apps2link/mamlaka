package com.mamlaka.athkiya.domain

data class GameState(
    val loaded: Boolean = false,
    val stars: Int = 0,
    val coins: Int = 0,
    val points: Int = 0,
    val sessionsCompleted: Int = 0,
    val age: Int = 4,
    val soundOn: Boolean = true,
    val voiceOn: Boolean = true,
    val reduceMotion: Boolean = false,
    val introSeen: Boolean = false,
    /** Best stars (0..3) per "<gameKey>_<LEVEL>". */
    val bestStars: Map<String, Int> = emptyMap(),
) {
    fun best(gameKey: String, level: GameLevel): Int = bestStars["${gameKey}_${level.name}"] ?: 0

    /** Easy is always open; the next level opens after one star on the previous one. */
    fun isLevelOpen(gameKey: String, level: GameLevel): Boolean =
        level.ordinal == 0 || best(gameKey, GameLevel.entries[level.ordinal - 1]) >= 1
}

data class GameResult(
    val stars: Int,
    val coins: Int,
    val points: Int = 0,
    val gameKey: String = "letters_tap",
    val level: GameLevel? = null,
)
