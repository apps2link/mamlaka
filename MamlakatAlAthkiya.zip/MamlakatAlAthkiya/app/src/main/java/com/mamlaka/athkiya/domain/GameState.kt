package com.mamlaka.athkiya.domain

data class GameState(
    val loaded: Boolean = false,
    val stars: Int = 0,
    val coins: Int = 0,
    val sessionsCompleted: Int = 0,
    val age: Int = 4,
    val soundOn: Boolean = true,
    val voiceOn: Boolean = true,
    val reduceMotion: Boolean = false,
    val introSeen: Boolean = false,
)

data class GameResult(val stars: Int, val coins: Int)
