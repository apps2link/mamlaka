package com.mamlaka.athkiya.games.numbers

import com.mamlaka.athkiya.characters.Thing
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.domain.GameLevel
import kotlin.math.abs
import kotlin.random.Random

const val GAME_ROUNDS = 6

private val CountableThings = listOf(Thing.FROG, Thing.MONKEY, Thing.SHEEP, Thing.CHICK, Thing.APPLE, Thing.STAR, Thing.BALL)

/** Three distinct answer numbers: the right one plus two near misses, all >= 1. */
internal fun numberOptions(correct: Int, maxValue: Int, random: Random): List<Int> {
    val wrong = (1..maxValue + 2).filter { it != correct && abs(it - correct) <= 3 }.shuffled(random).take(2)
    val extra = (1..maxValue + 2).filter { it != correct && it !in wrong }.shuffled(random)
    return (wrong + extra).take(2).plus(correct).shuffled(random)
}

// ---------------------------------------------------------------- Counting

data class CountingRound(val thing: Thing, val count: Int, val options: List<Int>)

object CountingEngine {
    fun maxCount(level: GameLevel) = when (level) {
        GameLevel.EASY -> 5
        GameLevel.MEDIUM -> 10
        GameLevel.HARD -> 15
    }

    fun minCount(level: GameLevel) = when (level) {
        GameLevel.EASY -> 1
        GameLevel.MEDIUM -> 3
        GameLevel.HARD -> 6
    }

    fun build(level: GameLevel, random: Random = Random.Default): List<CountingRound> {
        val pool = (minCount(level)..maxCount(level)).toList()
        val counts = (pool.shuffled(random) + pool.shuffled(random)).take(GAME_ROUNDS)
        val things = CountableThings.shuffled(random)
        return counts.mapIndexed { i, count ->
            CountingRound(things[i % things.size], count, numberOptions(count, maxCount(level), random))
        }
    }
}

// -------------------------------------------------------------- Comparison

enum class CmpType { MORE, LESS, SYMBOL }
enum class Choice { LEFT, EQUAL, RIGHT }

data class ComparisonRound(
    val left: Thing,
    val right: Thing,
    val leftCount: Int,
    val rightCount: Int,
    val type: CmpType,
) {
    /** MORE / SYMBOL: pick the bigger side (LEFT also means "left > right" for symbols); LESS: the smaller. */
    val correct: Choice
        get() = when {
            leftCount == rightCount -> Choice.EQUAL
            type == CmpType.LESS -> if (leftCount < rightCount) Choice.LEFT else Choice.RIGHT
            else -> if (leftCount > rightCount) Choice.LEFT else Choice.RIGHT
        }
}

object ComparisonEngine {
    fun maxCount(level: GameLevel) = when (level) {
        GameLevel.EASY -> 5
        GameLevel.MEDIUM -> 8
        GameLevel.HARD -> 10
    }

    fun build(level: GameLevel, random: Random = Random.Default): List<ComparisonRound> {
        val max = maxCount(level)
        val minDiff = if (level == GameLevel.EASY) 2 else 1
        val types = when (level) {
            GameLevel.EASY -> listOf(CmpType.MORE)
            GameLevel.MEDIUM -> listOf(CmpType.MORE, CmpType.LESS)
            GameLevel.HARD -> listOf(CmpType.MORE, CmpType.LESS, CmpType.SYMBOL)
        }
        return List(GAME_ROUNDS) { i ->
            val equal = level != GameLevel.EASY && random.nextFloat() < 0.2f
            var a: Int
            var b: Int
            if (equal) {
                a = random.nextInt(1, max + 1)
                b = a
            } else {
                do {
                    a = random.nextInt(1, max + 1)
                    b = random.nextInt(1, max + 1)
                } while (abs(a - b) < minDiff)
            }
            val pair = CountableThings.shuffled(random).take(2)
            ComparisonRound(pair[0], pair[1], a, b, types[(i + random.nextInt(types.size)) % types.size])
        }
    }
}

// ----------------------------------------------------------------- Eggs

enum class Slot { EGG, CHICK, EMPTY }

data class EggRound(
    val rows: Int,
    val cols: Int,
    val slots: List<Slot>,
    val ask: Slot,
    val answer: Int,
    val options: List<Int>,
)

object EggEngine {
    fun build(level: GameLevel, random: Random = Random.Default): List<EggRound> {
        val rows = if (level == GameLevel.EASY) 2 else 3
        val cols = if (level == GameLevel.HARD) 4 else 3
        return List(GAME_ROUNDS) {
            var round: EggRound
            do {
                val emptyChance = if (level == GameLevel.HARD) 0.15f else 0f
                val slots = List(rows * cols) {
                    val r = random.nextFloat()
                    when {
                        r < emptyChance -> Slot.EMPTY
                        r < emptyChance + 0.35f -> Slot.CHICK
                        else -> Slot.EGG
                    }
                }
                val ask = if (level == GameLevel.EASY) Slot.EGG else if (random.nextBoolean()) Slot.EGG else Slot.CHICK
                val answer = slots.count { it == ask }
                round = EggRound(rows, cols, slots, ask, answer, numberOptions(answer.coerceAtLeast(1), rows * cols, random))
            } while (round.answer < 1)
            round
        }
    }
}

// ----------------------------------------------------------------- Clock

data class ClockRound(val hour: Int, val minute: Int) {
    /** Arabic-digit label like ٧:٣٠. */
    val label: String get() = "$hour:${minute.toString().padStart(2, '0')}".toArabicDigits()

    fun matches(h: Int, m: Int): Boolean = h.mod(12) == hour.mod(12) && m == minute
}

object ClockEngine {
    fun build(level: GameLevel, random: Random = Random.Default): List<ClockRound> {
        val hours = (1..12).shuffled(random) + (1..12).shuffled(random)
        return List(GAME_ROUNDS) { i ->
            val minute = when (level) {
                GameLevel.EASY -> 0
                GameLevel.MEDIUM -> listOf(0, 30).random(random)
                GameLevel.HARD ->
                    if (random.nextFloat() < 0.6f) listOf(0, 15, 30, 45).random(random)
                    else (1..11).map { it * 5 }.random(random)
            }
            ClockRound(hours[i], minute)
        }
    }
}
