package com.mamlaka.athkiya.games.length

import com.mamlaka.athkiya.domain.GameLevel
import kotlin.math.abs
import kotlin.random.Random

enum class LengthAsk { LONGEST, SHORTEST }

/** [lengths] are fractions (0.3..1.0) of the available width; [colors] index into the worm palette. */
data class LengthRound(val lengths: List<Float>, val colors: List<Int>, val ask: LengthAsk) {
    val target: Int
        get() = if (ask == LengthAsk.LONGEST) lengths.indices.maxByOrNull { lengths[it] }!! else lengths.indices.minByOrNull { lengths[it] }!!
}

object LengthEngine {
    const val ROUNDS = 6
    const val PALETTE_SIZE = 5

    fun wormCount(level: GameLevel) = when (level) {
        GameLevel.EASY -> 3
        GameLevel.MEDIUM -> 4
        GameLevel.HARD -> 5
    }

    fun minGap(level: GameLevel) = when (level) {
        GameLevel.EASY -> 0.25f
        GameLevel.MEDIUM -> 0.15f
        GameLevel.HARD -> 0.09f
    }

    fun build(level: GameLevel, random: Random = Random.Default): List<LengthRound> =
        List(ROUNDS) { i ->
            val n = wormCount(level)
            val gap = minGap(level)
            var lengths: List<Float>? = null
            repeat(300) {
                if (lengths == null) {
                    val candidate = List(n) { 0.3f + random.nextFloat() * 0.7f }
                    val ok = candidate.indices.all { a -> candidate.indices.all { b -> a == b || abs(candidate[a] - candidate[b]) >= gap } }
                    if (ok) lengths = candidate
                }
            }
            // guaranteed fallback: evenly spaced lengths in random order
            val chosen = lengths ?: List(n) { 0.3f + 0.7f * it / (n - 1) }.shuffled(random)
            val ask = when {
                level == GameLevel.EASY -> if (i % 2 == 0) LengthAsk.LONGEST else LengthAsk.SHORTEST
                random.nextBoolean() -> LengthAsk.LONGEST
                else -> LengthAsk.SHORTEST
            }
            LengthRound(
                lengths = chosen,
                colors = (0 until PALETTE_SIZE).shuffled(random).take(n),
                ask = ask,
            )
        }
}
