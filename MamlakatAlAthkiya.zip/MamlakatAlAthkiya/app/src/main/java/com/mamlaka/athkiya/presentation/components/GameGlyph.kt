package com.mamlaka.athkiya.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import com.mamlaka.athkiya.characters.Thing
import com.mamlaka.athkiya.characters.ThingIcon
import com.mamlaka.athkiya.domain.GameId
import com.mamlaka.athkiya.presentation.theme.Palette

/** Small drawn emblem for a game card. */
@Composable
fun GameGlyph(game: GameId, size: Dp) {
    when (game) {
        GameId.COUNTING -> ThingIcon(Thing.SHEEP, size)
        GameId.COMPARISON -> ThingIcon(Thing.FROG, size)
        GameId.EGGS -> ThingIcon(Thing.CHICK, size)
        GameId.SHAPES -> ShapeIcon(ShapeKind.TRIANGLE, size)
        GameId.LENGTH -> WormIcon(WormColors[3], 0, size, size * 0.5f)
        GameId.CLOCK -> Canvas(Modifier.size(size)) {
            val s = this.size.minDimension
            val c = Offset(s / 2f, s / 2f)
            drawCircle(Palette.Sun, s * 0.48f, c)
            drawCircle(Color.White, s * 0.40f, c)
            drawLine(Palette.Coral, c, Offset(c.x, c.y - s * 0.2f), s * 0.07f, StrokeCap.Round)
            drawLine(Palette.Blue, c, Offset(c.x + s * 0.24f, c.y), s * 0.06f, StrokeCap.Round)
            drawCircle(Palette.Ink, s * 0.05f, c)
        }
    }
}
