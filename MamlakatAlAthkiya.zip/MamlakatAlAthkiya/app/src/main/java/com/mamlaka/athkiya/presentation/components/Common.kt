package com.mamlaka.athkiya.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.animations.KingdomBackground
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.core.toArabicDigits
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix

/**
 * Every screen sits inside this: the layered kingdom background, system-bar safe area plus margin
 * (so nothing important touches the screen edges), and a max content width for tablets.
 */
@Composable
fun ScreenScaffold(
    parallax: () -> Float = { 0f },
    content: @Composable BoxScope.() -> Unit,
) {
    KingdomBackground(parallax = parallax) {
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(16.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Box(Modifier.widthIn(max = 720.dp).fillMaxSize()) { content() }
        }
    }
}

@Composable
fun BigButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(32.dp)
    Box(
        modifier
            .bouncyClickable(onClick)
            .heightIn(min = 76.dp)
            .shadow(8.dp, shape)
            .background(Brush.verticalGradient(listOf(color.mix(Color.White, 0.25f), color)), shape)
            .border(3.dp, Color.White.copy(alpha = 0.6f), shape)
            .padding(horizontal = 32.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MamlakaType.Button, color = Color.White)
    }
}

/** Round, large icon button (back, parent area, replay sound). */
@Composable
fun RoundButton(
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Box(
        modifier
            .size(64.dp)
            .bouncyClickable(onClick)
            .shadow(6.dp, CircleShape)
            .background(color, CircleShape)
            .border(3.dp, Color.White.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center,
    ) { icon() }
}

@Composable
fun SpeechBubble(text: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier
            .shadow(6.dp, shape)
            .background(Color.White, shape)
            .border(3.dp, Palette.Purple.copy(alpha = 0.35f), shape)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = MamlakaType.Body, color = Palette.Ink, textAlign = TextAlign.Center)
    }
}

@Composable
fun StatsBar(stars: Int, coins: Int, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        StatChip { StarIcon(28.dp, filled = true); Spacer(Modifier.width(6.dp)); Text(stars.toArabicDigits(), style = MamlakaType.Body, color = Palette.Ink) }
        StatChip { CoinIcon(26.dp); Spacer(Modifier.width(6.dp)); Text(coins.toArabicDigits(), style = MamlakaType.Body, color = Palette.Ink) }
    }
}

@Composable
private fun StatChip(content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier
            .background(Color.White.copy(alpha = 0.92f), shape)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

/** Standard top row: back button on the start side, [trailing] on the end side. */
@Composable
fun TopBar(onBack: (() -> Unit)?, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            RoundButton(Palette.Purple, onClick = onBack) { BackIcon() }
        } else {
            Spacer(Modifier.size(64.dp))
        }
        trailing()
    }
}

/** Colors that give each game its own identity inside the shared kingdom style. */
data class GameTheme(val top: Color, val bottom: Color, val accent: Color)

/**
 * Game page: its own colored backdrop with soft decorations (like the reference designs),
 * safe-area padding and a max width for tablets.
 */
@Composable
fun GameScaffold(theme: GameTheme, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(theme.top, theme.bottom)))
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val faint = Color.White.copy(alpha = 0.22f)
            drawCircle(faint, size.minDimension * 0.30f, androidx.compose.ui.geometry.Offset(size.width * 0.95f, size.height * 0.08f))
            drawCircle(faint, size.minDimension * 0.22f, androidx.compose.ui.geometry.Offset(size.width * 0.02f, size.height * 0.75f))
            val arm = size.minDimension * 0.05f
            for ((fx, fy) in listOf(0.12f to 0.15f, 0.88f to 0.6f, 0.2f to 0.93f)) {
                val cx = size.width * fx
                val cy = size.height * fy
                drawLine(faint, androidx.compose.ui.geometry.Offset(cx - arm, cy), androidx.compose.ui.geometry.Offset(cx + arm, cy), arm * 0.6f, androidx.compose.ui.graphics.StrokeCap.Round)
                drawLine(faint, androidx.compose.ui.geometry.Offset(cx, cy - arm), androidx.compose.ui.geometry.Offset(cx, cy + arm), arm * 0.6f, androidx.compose.ui.graphics.StrokeCap.Round)
            }
        }
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(16.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Box(Modifier.widthIn(max = 720.dp).fillMaxSize()) { content() }
        }
    }
}

/** Big white rounded answer card (numbers, names, pictures). */
@Composable
fun AnswerTile(
    modifier: Modifier = Modifier,
    accent: Color,
    dimmed: Boolean = false,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier
            .heightIn(min = 96.dp)
            .alpha(if (dimmed) 0.45f else 1f)
            .bouncyClickable(onClick)
            .shadow(8.dp, shape)
            .background(Color.White, shape)
            .border(4.dp, accent.copy(alpha = 0.55f), shape)
            .padding(12.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}
