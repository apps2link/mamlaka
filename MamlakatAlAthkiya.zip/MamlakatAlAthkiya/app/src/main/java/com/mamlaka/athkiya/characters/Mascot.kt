package com.mamlaka.athkiya.characters

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.animations.bob
import com.mamlaka.athkiya.animations.tilt
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix

enum class MascotKind { LULU, ZIZO, TOTO }

/** Facial expressions: happy, surprised, thinking, slightly sad (on a wrong answer), cheering. */
enum class Mood { HAPPY, SURPRISED, THINKING, SAD, CHEER }

enum class MascotAction { IDLE, JUMP, WAVE }

/**
 * The three guide characters, drawn once here so they look identical on every screen.
 * LULU: cheerful orange friend. ZIZO: curious teal explorer with an antenna. TOTO: small funny yellow chick.
 */
@Composable
fun Mascot(
    kind: MascotKind,
    modifier: Modifier = Modifier.size(140.dp),
    mood: Mood = Mood.HAPPY,
    action: MascotAction = MascotAction.IDLE,
) {
    val motion = when (action) {
        MascotAction.IDLE -> Modifier.bob(amplitude = 4.dp, periodMillis = 1600, delayMillis = kind.ordinal * 300)
        MascotAction.JUMP -> Modifier.bob(amplitude = 18.dp, periodMillis = 450)
        MascotAction.WAVE -> Modifier.tilt(degrees = 8f, periodMillis = 700)
    }
    Box(modifier.then(motion)) {
        Canvas(Modifier.fillMaxSize()) {
            drawMascot(kind, mood, armsUp = action == MascotAction.WAVE || mood == Mood.CHEER)
        }
    }
}

private val MouthRed = Color(0xFF8B1E3F)

private fun DrawScope.drawMascot(kind: MascotKind, mood: Mood, armsUp: Boolean) {
    val w = size.width
    val h = size.height
    val r = w * 0.34f * (if (kind == MascotKind.TOTO) 0.85f else 1f)
    val cx = w / 2f
    val cy = h * 0.60f
    val body = when (kind) {
        MascotKind.LULU -> Palette.Orange
        MascotKind.ZIZO -> Palette.Teal
        MascotKind.TOTO -> Palette.Sun
    }
    val bodyDark = body.mix(Color.Black, 0.2f)
    val bodyLight = body.mix(Color.White, 0.4f)
    val line = r * 0.07f

    // ground shadow
    drawOval(Color(0x26000000), Offset(cx - r * 0.9f, h * 0.90f), Size(r * 1.8f, h * 0.07f))

    // parts behind the body
    when (kind) {
        MascotKind.LULU -> for (s in listOf(-1f, 1f)) {
            val ear = Path().apply {
                moveTo(cx + s * r * 0.20f, cy - r * 0.85f)
                lineTo(cx + s * r * 0.85f, cy - r * 1.40f)
                lineTo(cx + s * r * 1.02f, cy - r * 0.55f)
                close()
            }
            drawPath(ear, bodyDark)
            val inner = Path().apply {
                moveTo(cx + s * r * 0.35f, cy - r * 0.88f)
                lineTo(cx + s * r * 0.80f, cy - r * 1.20f)
                lineTo(cx + s * r * 0.90f, cy - r * 0.66f)
                close()
            }
            drawPath(inner, Palette.Pink)
        }
        MascotKind.ZIZO -> {
            drawLine(bodyDark, Offset(cx, cy - r * 0.9f), Offset(cx, cy - r * 1.45f), strokeWidth = line * 1.4f, cap = StrokeCap.Round)
            drawCircle(Palette.Pink, r * 0.16f, Offset(cx, cy - r * 1.5f))
            for (s in listOf(-1f, 1f)) drawCircle(bodyDark, r * 0.26f, Offset(cx + s * r * 1.0f, cy - r * 0.1f))
        }
        MascotKind.TOTO -> {
            for (i in -1..1) {
                drawLine(
                    Palette.Orange,
                    Offset(cx + i * r * 0.1f, cy - r * 0.9f),
                    Offset(cx + i * r * 0.35f, cy - r * 1.4f),
                    strokeWidth = line * 1.6f,
                    cap = StrokeCap.Round,
                )
            }
            for (s in listOf(-1f, 1f)) drawOval(Palette.Orange, Offset(cx + s * r * 0.4f - r * 0.2f, cy + r * 0.92f), Size(r * 0.4f, r * 0.2f))
        }
    }

    // body + belly
    drawCircle(
        Brush.radialGradient(listOf(bodyLight, body), center = Offset(cx - r * 0.3f, cy - r * 0.4f), radius = r * 1.6f),
        r,
        Offset(cx, cy),
    )
    drawOval(Color.White.copy(alpha = 0.35f), Offset(cx - r * 0.55f, cy + r * 0.10f), Size(r * 1.1f, r * 0.8f))

    // arms
    for (s in listOf(-1f, 1f)) {
        val start = Offset(cx + s * r * 0.92f, cy + r * 0.30f)
        val end = if (armsUp) Offset(cx + s * r * 1.30f, cy - r * 0.50f) else Offset(cx + s * r * 1.20f, cy + r * 0.60f)
        drawLine(body, start, end, strokeWidth = r * 0.24f, cap = StrokeCap.Round)
    }

    // eyes
    val eyeY = cy - r * 0.15f
    val eyeDx = r * 0.40f
    val er = r * 0.22f
    for (s in listOf(-1f, 1f)) {
        val ex = cx + s * eyeDx
        if (mood == Mood.CHEER) {
            drawArc(
                Palette.Ink, 200f, 140f, false,
                topLeft = Offset(ex - er * 0.8f, eyeY - er * 0.5f),
                size = Size(er * 1.6f, er * 1.2f),
                style = Stroke(width = line * 1.2f, cap = StrokeCap.Round),
            )
        } else {
            drawCircle(Color.White, er, Offset(ex, eyeY))
            val px = if (mood == Mood.THINKING) er * 0.35f else 0f
            val py = when (mood) {
                Mood.THINKING -> -er * 0.3f
                Mood.SAD -> er * 0.25f
                else -> 0f
            }
            val pr = if (mood == Mood.SURPRISED) er * 0.4f else er * 0.55f
            drawCircle(Palette.Ink, pr, Offset(ex + px, eyeY + py))
            drawCircle(Color.White, er * 0.18f, Offset(ex + px + er * 0.15f, eyeY + py - er * 0.18f))
        }
        if (mood == Mood.THINKING && s > 0f) {
            drawLine(Palette.Ink, Offset(ex - er, eyeY - er * 1.5f), Offset(ex + er, eyeY - er * 1.8f), strokeWidth = line, cap = StrokeCap.Round)
        }
        if (mood == Mood.SAD) {
            drawLine(Palette.Ink, Offset(ex - s * er, eyeY - er * 1.7f), Offset(ex + s * er, eyeY - er * 1.2f), strokeWidth = line, cap = StrokeCap.Round)
        }
    }

    // beak (Toto)
    if (kind == MascotKind.TOTO) {
        val beak = Path().apply {
            moveTo(cx - r * 0.14f, cy + r * 0.02f)
            lineTo(cx + r * 0.14f, cy + r * 0.02f)
            lineTo(cx, cy + r * 0.22f)
            close()
        }
        drawPath(beak, Palette.Orange)
    }

    // cheeks
    for (s in listOf(-1f, 1f)) drawCircle(Palette.Pink.copy(alpha = 0.5f), r * 0.13f, Offset(cx + s * r * 0.62f, cy + r * 0.20f))

    // mouth
    val my = cy + r * (if (kind == MascotKind.TOTO) 0.40f else 0.30f)
    when (mood) {
        Mood.HAPPY -> drawArc(
            Palette.Ink, 20f, 140f, false,
            topLeft = Offset(cx - r * 0.30f, my - r * 0.20f), size = Size(r * 0.6f, r * 0.4f),
            style = Stroke(width = line, cap = StrokeCap.Round),
        )
        Mood.CHEER -> drawArc(
            MouthRed, 0f, 180f, true,
            topLeft = Offset(cx - r * 0.30f, my - r * 0.15f), size = Size(r * 0.6f, r * 0.5f),
        )
        Mood.SURPRISED -> drawOval(MouthRed, Offset(cx - r * 0.12f, my - r * 0.05f), Size(r * 0.24f, r * 0.32f))
        Mood.THINKING -> drawLine(
            Palette.Ink, Offset(cx - r * 0.10f, my + r * 0.10f), Offset(cx + r * 0.22f, my + r * 0.05f),
            strokeWidth = line, cap = StrokeCap.Round,
        )
        Mood.SAD -> drawArc(
            Palette.Ink, 200f, 140f, false,
            topLeft = Offset(cx - r * 0.25f, my), size = Size(r * 0.5f, r * 0.3f),
            style = Stroke(width = line, cap = StrokeCap.Round),
        )
    }
}
