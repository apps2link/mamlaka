package com.mamlaka.athkiya.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mamlaka.athkiya.R
import com.mamlaka.athkiya.animations.bouncyClickable
import com.mamlaka.athkiya.characters.Mascot
import com.mamlaka.athkiya.characters.MascotKind
import com.mamlaka.athkiya.characters.Mood
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.domain.World
import com.mamlaka.athkiya.presentation.components.LockBadge
import com.mamlaka.athkiya.presentation.components.ScreenScaffold
import com.mamlaka.athkiya.presentation.components.SpeechBubble
import com.mamlaka.athkiya.presentation.components.StatsBar
import com.mamlaka.athkiya.presentation.components.TopBar
import com.mamlaka.athkiya.presentation.components.WorldIcon
import com.mamlaka.athkiya.presentation.theme.MamlakaType
import com.mamlaka.athkiya.presentation.theme.Palette
import com.mamlaka.athkiya.presentation.theme.mix
import kotlinx.coroutines.delay

private val NodeHeight = 190.dp
private val NodeSize = 120.dp
private fun xFraction(index: Int) = if (index % 2 == 0) 0.30f else 0.70f

/** Interactive kingdom map: a winding path through the seven worlds, with parallax hills behind. */
@Composable
fun MapScreen(
    state: GameState,
    onSpeak: (String) -> Unit,
    onBack: () -> Unit,
    onWorld: (World) -> Unit,
) {
    val worlds = World.entries
    val scroll = rememberScrollState()
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(message) {
        if (message != null) {
            delay(3500)
            message = null
        }
    }

    ScreenScaffold(parallax = { if (scroll.maxValue > 0) scroll.value / scroll.maxValue.toFloat() else 0f }) {
        Column(Modifier.fillMaxSize()) {
            TopBar(onBack = onBack) { StatsBar(state.stars, state.coins) }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.verticalScroll(scroll)) {
                    BoxWithConstraints(Modifier.fillMaxWidth().height(NodeHeight * worlds.size + 40.dp)) {
                        val boxWidth = maxWidth
                        Canvas(Modifier.fillMaxSize()) {
                            val nh = NodeHeight.toPx()
                            val centerY = 10.dp.toPx() + NodeSize.toPx() / 2f
                            val points = worlds.indices.map { Offset(size.width * xFraction(it), nh * it + centerY) }
                            val path = Path().apply {
                                moveTo(points[0].x, points[0].y)
                                for (i in 1 until points.size) {
                                    val a = points[i - 1]
                                    val b = points[i]
                                    cubicTo(a.x, a.y + nh * 0.5f, b.x, b.y - nh * 0.5f, b.x, b.y)
                                }
                            }
                            drawPath(
                                path,
                                Color.White.copy(alpha = 0.85f),
                                style = Stroke(
                                    width = 10.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f, 30f)),
                                ),
                            )
                        }
                        worlds.forEachIndexed { i, world ->
                            val soon = stringResource(R.string.map_soon, stringResource(world.title))
                            WorldNode(
                                world = world,
                                modifier = Modifier.offset(
                                    x = boxWidth * xFraction(i) - 70.dp,
                                    y = NodeHeight * i + 10.dp,
                                ),
                                onClick = {
                                    if (world.available) {
                                        onWorld(world)
                                    } else {
                                        message = soon
                                        onSpeak(soon)
                                    }
                                },
                            )
                        }
                    }
                }
                MapMessage(
                    message = message,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }
}


@Composable
private fun MapMessage(message: String?, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = message != null,
        modifier = modifier,
        enter = fadeIn() + slideInVertically { it },
        exit = fadeOut() + slideOutVertically { it },
    ) {
        Row(
            Modifier.padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Mascot(MascotKind.TOTO, Modifier.size(96.dp), mood = Mood.THINKING)
            SpeechBubble(message ?: "", Modifier.weight(1f))
        }
    }
}

@Composable
private fun WorldNode(world: World, modifier: Modifier, onClick: () -> Unit) {
    val color = world.color()
    Column(modifier.width(140.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(NodeSize)
                .bouncyClickable(onClick)
                .shadow(10.dp, CircleShape)
                .background(Brush.verticalGradient(listOf(color.mix(Color.White, 0.3f), color)), CircleShape)
                .border(5.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            WorldIcon(world, 72.dp)
            if (!world.available) {
                Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) { LockBadge() }
            }
        }
        Text(
            stringResource(world.title),
            style = MamlakaType.Body,
            color = Palette.Ink,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 6.dp)
                .background(Color.White.copy(alpha = 0.92f), RoundedCornerShape(16.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}
