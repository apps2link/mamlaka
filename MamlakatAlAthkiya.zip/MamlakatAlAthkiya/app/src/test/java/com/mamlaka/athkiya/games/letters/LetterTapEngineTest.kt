package com.mamlaka.athkiya.games.letters

import com.mamlaka.athkiya.domain.ArabicLetters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class LetterTapEngineTest {

    @Test
    fun letterBankHas28UniqueLettersWithWords() {
        val letters = ArabicLetters.all
        assertEquals(28, letters.size)
        assertEquals(28, letters.map { it.ch }.toSet().size)
        assertEquals(28, letters.map { it.id }.toSet().size)
        assertTrue(letters.all { it.name.isNotBlank() && it.word.isNotBlank() })
    }

    @Test
    fun everyAgeGetsValidRounds() {
        for (age in 3..6) {
            val rounds = LetterTapEngine.buildRounds(age, Random(age))
            assertEquals(LetterTapEngine.ROUNDS, rounds.size)
            val pool = ArabicLetters.all.take(LetterTapEngine.poolSizeForAge(age)).toSet()
            rounds.forEach { r ->
                assertEquals(LetterTapEngine.optionCountForAge(age), r.options.size)
                assertEquals(r.options.size, r.options.toSet().size)
                assertEquals(1, r.options.count { it == r.target })
                assertTrue(pool.containsAll(r.options))
            }
            assertEquals(rounds.size, rounds.map { it.target }.toSet().size)
        }
    }

    @Test
    fun starsAndCoinsFollowMistakes() {
        assertEquals(3, LetterTapEngine.starsFor(0))
        assertEquals(3, LetterTapEngine.starsFor(1))
        assertEquals(2, LetterTapEngine.starsFor(3))
        assertEquals(1, LetterTapEngine.starsFor(10))
        assertEquals(8, LetterTapEngine.coinsFor(0))
        assertEquals(1, LetterTapEngine.coinsFor(50))
    }
}
