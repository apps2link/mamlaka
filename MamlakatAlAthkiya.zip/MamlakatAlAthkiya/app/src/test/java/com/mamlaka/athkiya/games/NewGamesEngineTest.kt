package com.mamlaka.athkiya.games

import com.mamlaka.athkiya.core.NumberWords
import com.mamlaka.athkiya.domain.GameLevel
import com.mamlaka.athkiya.domain.GameState
import com.mamlaka.athkiya.games.length.LengthAsk
import com.mamlaka.athkiya.games.length.LengthEngine
import com.mamlaka.athkiya.games.numbers.Choice
import com.mamlaka.athkiya.games.numbers.ClockEngine
import com.mamlaka.athkiya.games.numbers.ClockRound
import com.mamlaka.athkiya.games.numbers.CmpType
import com.mamlaka.athkiya.games.numbers.ComparisonEngine
import com.mamlaka.athkiya.games.numbers.ComparisonRound
import com.mamlaka.athkiya.games.numbers.CountingEngine
import com.mamlaka.athkiya.games.numbers.EggEngine
import com.mamlaka.athkiya.games.numbers.GAME_ROUNDS
import com.mamlaka.athkiya.games.numbers.Slot
import com.mamlaka.athkiya.games.shapes.ShapeMode
import com.mamlaka.athkiya.games.shapes.ShapesEngine
import com.mamlaka.athkiya.characters.Thing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class NewGamesEngineTest {
    private val levels = GameLevel.entries

    @Test
    fun countingRoundsAreValid() {
        for (level in levels) {
            val rounds = CountingEngine.build(level, Random(1))
            assertEquals(GAME_ROUNDS, rounds.size)
            rounds.forEach { r ->
                assertTrue(r.count in CountingEngine.minCount(level)..CountingEngine.maxCount(level))
                assertEquals(3, r.options.size)
                assertEquals(3, r.options.toSet().size)
                assertTrue(r.count in r.options)
                assertTrue(r.options.all { it >= 1 })
            }
        }
    }

    @Test
    fun comparisonAnswersAreCorrect() {
        val more = ComparisonRound(Thing.FROG, Thing.MONKEY, 5, 2, CmpType.MORE)
        assertEquals(Choice.LEFT, more.correct)
        val less = ComparisonRound(Thing.FROG, Thing.MONKEY, 5, 2, CmpType.LESS)
        assertEquals(Choice.RIGHT, less.correct)
        val equal = ComparisonRound(Thing.FROG, Thing.MONKEY, 4, 4, CmpType.SYMBOL)
        assertEquals(Choice.EQUAL, equal.correct)
        val symbol = ComparisonRound(Thing.FROG, Thing.MONKEY, 2, 7, CmpType.SYMBOL)
        assertEquals(Choice.RIGHT, symbol.correct)
        for (level in levels) {
            ComparisonEngine.build(level, Random(2)).forEach { r ->
                assertTrue(r.leftCount in 1..ComparisonEngine.maxCount(level))
                assertTrue(r.rightCount in 1..ComparisonEngine.maxCount(level))
                assertTrue(r.left != r.right)
                if (level == GameLevel.EASY) {
                    assertEquals(CmpType.MORE, r.type)
                    assertTrue(r.leftCount != r.rightCount)
                }
            }
        }
    }

    @Test
    fun eggRoundsHaveAnswerInOptions() {
        for (level in levels) {
            EggEngine.build(level, Random(3)).forEach { r ->
                assertEquals(r.rows * r.cols, r.slots.size)
                assertEquals(r.slots.count { it == r.ask }, r.answer)
                assertTrue(r.answer >= 1)
                assertTrue(r.answer in r.options)
                assertEquals(r.options.size, r.options.toSet().size)
                if (level != GameLevel.HARD) assertFalse(Slot.EMPTY in r.slots)
            }
        }
    }

    @Test
    fun clockTargetsMatchLevel() {
        ClockEngine.build(GameLevel.EASY, Random(4)).forEach { assertEquals(0, it.minute) }
        ClockEngine.build(GameLevel.MEDIUM, Random(4)).forEach { assertTrue(it.minute == 0 || it.minute == 30) }
        ClockEngine.build(GameLevel.HARD, Random(4)).forEach { assertEquals(0, it.minute % 5) }
        val r = ClockRound(7, 30)
        assertTrue(r.matches(7, 30))
        assertTrue(ClockRound(12, 0).matches(0, 0))
        assertFalse(r.matches(8, 30))
        assertEquals("٧:٣٠", r.label)
    }

    @Test
    fun clockPhrasesAreArabic() {
        assertEquals("الساعة سبعة", NumberWords.clockPhrase(7, 0))
        assertEquals("الساعة سبعة والنصف", NumberWords.clockPhrase(7, 30))
        assertEquals("الساعة سبعة والربع", NumberWords.clockPhrase(7, 15))
        assertEquals("الساعة ثمانية إلا ربع", NumberWords.clockPhrase(7, 45))
        assertEquals("الساعة واحد إلا ربع", NumberWords.clockPhrase(12, 45))
    }

    @Test
    fun lengthTargetIsUniqueAndGapsRespected() {
        for (level in levels) {
            LengthEngine.build(level, Random(5)).forEach { r ->
                assertEquals(LengthEngine.wormCount(level), r.lengths.size)
                val sorted = r.lengths.sorted()
                for (i in 1 until sorted.size) assertTrue(sorted[i] - sorted[i - 1] >= LengthEngine.minGap(level) - 0.0001f)
                val expected = if (r.ask == LengthAsk.LONGEST) r.lengths.max() else r.lengths.min()
                assertEquals(expected, r.lengths[r.target])
            }
        }
    }

    @Test
    fun shapesRoundsAreValid() {
        for (level in levels) {
            ShapesEngine.build(level, Random(6)).forEach { r ->
                assertEquals(ShapesEngine.optionCount(level), r.options.size)
                assertEquals(r.options.size, r.options.toSet().size)
                assertTrue(r.target in r.options)
                assertTrue(ShapesEngine.pool(level).containsAll(r.options))
                if (level == GameLevel.EASY) assertEquals(ShapeMode.NAME, r.mode)
            }
        }
    }

    @Test
    fun levelsUnlockAfterOneStar() {
        val none = GameState()
        assertTrue(none.isLevelOpen("counting", GameLevel.EASY))
        assertFalse(none.isLevelOpen("counting", GameLevel.MEDIUM))
        val passed = GameState(bestStars = mapOf("counting_EASY" to 1))
        assertTrue(passed.isLevelOpen("counting", GameLevel.MEDIUM))
        assertFalse(passed.isLevelOpen("counting", GameLevel.HARD))
    }
}
